import React, { useState, useEffect } from 'react';
import { Project } from './types';
import { CustomCursor } from './components/CustomCursor';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Marquee } from './components/Marquee';
import { About } from './components/About';
import { Services } from './components/Services';
import { FeaturedWork } from './components/FeaturedWork';
import { Skills } from './components/Skills';
import { Process } from './components/Process';
import { WhyMe } from './components/WhyMe';
import { AiVisuals } from './components/AiVisuals';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ProjectModal } from './components/ProjectModal';
import {
  playClickSound,
  playHoverSound,
  playSoundToggleCue,
  playModalOpenSound,
  playModalCloseSound
} from './utils/sound';

export default function App() {
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('hasan_portfolio_sound_enabled') === 'true';
    }
    return false;
  });

  const toggleSound = () => {
    const nextState = !soundEnabled;
    setSoundEnabled(nextState);
    if (typeof window !== 'undefined') {
      localStorage.setItem('hasan_portfolio_sound_enabled', String(nextState));
    }
    playSoundToggleCue(nextState);
  };

  const handleSelectProject = (project: Project) => {
    if (soundEnabled) {
      playModalOpenSound();
    }
    setSelectedProject(project);
  };

  const handleCloseProject = () => {
    if (soundEnabled) {
      playModalCloseSound();
    }
    setSelectedProject(null);
  };

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.remove('light');
      root.classList.add('dark');
      document.body.className = 'bg-[#0c0c0c] text-[#f4efe6] antialiased selection:bg-[#d4af37] selection:text-black';
    } else {
      root.classList.remove('dark');
      root.classList.add('light');
      document.body.className = 'bg-[#f4efe6] text-[#0c0c0c] antialiased selection:bg-[#d4af37] selection:text-black';
    }
  }, [darkMode]);

  // Global sound interaction cues when sound is active
  useEffect(() => {
    if (!soundEnabled) return;

    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      // Trigger click audio on interactive controls
      if (target.closest('a, button, [role="button"], input, textarea, select, [data-cursor]')) {
        playClickSound();
      }
    };

    const handleGlobalMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      // Trigger subtle air blip on interactive links and cards
      if (target.closest('a, button, [role="button"], [data-cursor]')) {
        playHoverSound();
      }
    };

    window.addEventListener('click', handleGlobalClick, { capture: true, passive: true });
    window.addEventListener('mouseover', handleGlobalMouseOver, { passive: true });

    return () => {
      window.removeEventListener('click', handleGlobalClick, { capture: true });
      window.removeEventListener('mouseover', handleGlobalMouseOver);
    };
  }, [soundEnabled]);

  return (
    <div className="relative min-h-screen font-sans">
      {/* Desktop Custom Cursor */}
      <CustomCursor />

      {/* Sticky Header Navigation */}
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        soundEnabled={soundEnabled}
        onToggleSound={toggleSound}
      />

      {/* Main Sections */}
      <main id="main-portfolio-content">
        {/* Hero Section with Creative-Tech Composition */}
        <Hero darkMode={darkMode} />

        {/* Continuous Moving Marquee */}
        <Marquee darkMode={darkMode} />

        {/* 01 / About Section & Personal Profile Card */}
        <About darkMode={darkMode} />

        {/* 02 / Services Section with AI Visual Creation */}
        <Services darkMode={darkMode} />

        {/* 03 / Selected Work (Featured Projects) */}
        <FeaturedWork
          onSelectProject={handleSelectProject}
          darkMode={darkMode}
        />

        {/* 04 / Skills Section */}
        <Skills darkMode={darkMode} />

        {/* 05 / Process (Timeline from Idea to Execution) */}
        <Process darkMode={darkMode} />

        {/* Value Proposition (Creative Thinking • Digital Execution) */}
        <WhyMe darkMode={darkMode} />

        {/* 06 / Dedicated AI Visuals Gallery (Instagram Connected) */}
        <AiVisuals darkMode={darkMode} />

        {/* Testimonials (Honest Coming Soon representation) */}
        <Testimonials darkMode={darkMode} />

        {/* Contact & Direct Channels */}
        <Contact darkMode={darkMode} />
      </main>

      {/* Footer */}
      <Footer darkMode={darkMode} />

      {/* Interactive Project Detail Modal */}
      {selectedProject && (
        <ProjectModal
          project={selectedProject}
          onClose={handleCloseProject}
          darkMode={darkMode}
        />
      )}
    </div>
  );
}
