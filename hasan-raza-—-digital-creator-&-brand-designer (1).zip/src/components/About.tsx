import React from 'react';
import { Sparkles, Quote, Terminal, Check } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { ProfileCard } from './ProfileCard';

interface AboutProps {
  darkMode: boolean;
}

export const About: React.FC<AboutProps> = ({ darkMode }) => {
  return (
    <section
      id="about"
      className={`py-24 border-b transition-colors ${
        darkMode ? 'border-white/10 bg-[#0c0c0c]' : 'border-black/10 bg-[#f4efe6]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Label */}
        <div className="flex items-center gap-2 mb-4">
          <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
            01 / ABOUT
          </span>
          <div className="h-[1px] w-12 bg-[#d4af37]/40" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Narrative & Principles (7 cols) */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* Headline */}
            <h2 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight uppercase leading-[1.08]">
              MORE THAN DESIGN.<br />
              <span className="text-[#d4af37]">I BUILD IDEAS.</span>
            </h2>

            {/* Core Paragraphs */}
            <div className={`space-y-5 text-base sm:text-lg leading-relaxed ${
              darkMode ? 'text-[#c2bcaf]' : 'text-[#383530]'
            }`}>
              <p>
                I’m Hasan Raza, a digital creator passionate about combining design, technology and AI to create meaningful digital experiences.
              </p>
              <p>
                From branding and visual design to video content, prompt engineering and AI-powered workflows, I enjoy turning ideas into practical and visually strong solutions.
              </p>
              <p className="font-medium text-[#f4efe6] dark:text-[#f4efe6] light:text-[#0c0c0c] border-l-2 border-[#d4af37] pl-4 italic">
                “My approach is simple: understand the idea, improve the concept, design the experience and build something people remember.”
              </p>
            </div>

            {/* Editorial Positioning Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className={`p-5 rounded-2xl border transition-all ${
                darkMode ? 'bg-white/3 border-white/10' : 'bg-black/3 border-black/10'
              }`}>
                <Quote className="w-5 h-5 text-[#d4af37] mb-2" />
                <p className="text-sm font-semibold tracking-tight text-[#f4efe6]">
                  “{PERSONAL_INFO.positioning}”
                </p>
                <span className="text-[11px] font-mono text-[#8a8a8a] mt-2 block">
                  — Creative Philosophy
                </span>
              </div>

              <div className={`p-5 rounded-2xl border transition-all ${
                darkMode ? 'bg-white/3 border-white/10' : 'bg-black/3 border-black/10'
              }`}>
                <Sparkles className="w-5 h-5 text-[#d4af37] mb-2" />
                <p className="text-sm font-semibold tracking-tight text-[#f4efe6]">
                  “{PERSONAL_INFO.supportingLine}”
                </p>
                <span className="text-[11px] font-mono text-[#8a8a8a] mt-2 block">
                  — Execution Method
                </span>
              </div>
            </div>

            {/* Key Creative Tenets */}
            <div className={`p-6 rounded-2xl border ${
              darkMode ? 'bg-white/2 border-white/10' : 'bg-black/2 border-black/10'
            }`}>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#d4af37] mb-4">
                <Terminal className="w-4 h-4" />
                <span>The Creative Formula</span>
              </div>
              <ul className="space-y-2.5 text-sm">
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                  <span><strong>Idea First:</strong> Strategy and emotional clarity dictate the medium.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                  <span><strong>AI as an Amplifier:</strong> Generative tech accelerates exploration while human taste polishes the final artifact.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
                  <span><strong>End-to-End Cohesion:</strong> Harmonizing brand identities, video edits, and digital interfaces into one unified narrative.</span>
                </li>
              </ul>
            </div>

          </div>

          {/* Right Column: Profile Card (5 cols) */}
          <div className="lg:col-span-5 lg:sticky lg:top-24">
            <ProfileCard darkMode={darkMode} />
          </div>

        </div>
      </div>
    </section>
  );
};
