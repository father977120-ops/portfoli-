import React, { useState } from 'react';
import { ArrowUpRight, Sparkles, Instagram, Filter } from 'lucide-react';
import { AiCategory } from '../types';
import { AI_VISUALS, PERSONAL_INFO } from '../data/portfolioData';

interface AiVisualsProps {
  darkMode: boolean;
}

export const AiVisuals: React.FC<AiVisualsProps> = ({ darkMode }) => {
  const [selectedCategory, setSelectedCategory] = useState<AiCategory>('ALL');

  const categories: AiCategory[] = [
    'ALL',
    'AI ART',
    'AI PORTRAITS',
    'AI PRODUCTS',
    'AI ADS',
    'AI CONCEPTS',
  ];

  const filteredItems = selectedCategory === 'ALL'
    ? AI_VISUALS
    : AI_VISUALS.filter((item) => item.category === selectedCategory);

  return (
    <section
      id="ai-visuals"
      className={`py-24 border-b transition-colors relative overflow-hidden ${
        darkMode ? 'border-white/10 bg-[#090909]' : 'border-black/10 bg-[#f7f3ec]'
      }`}
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
                06 / AI VISUALS
              </span>
              <div className="h-[1px] w-12 bg-[#d4af37]/40" />
            </div>
            
            <h2 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight uppercase leading-[1.06]">
              IMAGINE IT.<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#d4af37] via-amber-200 to-[#f4efe6]">
                CREATE IT WITH AI.
              </span>
            </h2>
          </div>

          <div className="max-w-md space-y-2">
            <p className={`text-base leading-relaxed ${
              darkMode ? 'text-[#a8a8a8]' : 'text-[#444]'
            }`}>
              Exploring the creative possibilities of AI to transform ideas into striking visual experiences. From editorial portraits to product packaging and surreal conceptual art.
            </p>
            <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Prompt Architecture • Generative Art Direction • Visual Synthesis</span>
            </div>
          </div>
        </div>

        {/* Categories Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar" id="ai-visual-filters">
          <div className="flex items-center gap-1.5 p-1 rounded-full border border-white/10 bg-white/5 backdrop-blur-md">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`text-xs font-mono uppercase tracking-wider px-4 py-2 rounded-full whitespace-nowrap transition-all duration-200 ${
                  selectedCategory === cat
                    ? 'bg-[#d4af37] text-black font-bold shadow-md'
                    : darkMode
                    ? 'text-[#a8a8a8] hover:text-white hover:bg-white/5'
                    : 'text-[#555] hover:text-black hover:bg-black/5'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Large Editorial Masonry / Visual Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <a
              key={item.id}
              href={item.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor="view"
              aria-label={`View ${item.title} on Instagram`}
              className={`group relative block rounded-3xl overflow-hidden border transition-all duration-500 ${
                item.aspectRatio === 'tall'
                  ? 'sm:row-span-2 aspect-[3/4] sm:aspect-auto'
                  : item.aspectRatio === 'wide'
                  ? 'aspect-[16/10]'
                  : 'aspect-square'
              } ${
                darkMode
                  ? 'bg-[#121212] border-white/10 hover:border-[#d4af37]/60 shadow-xl'
                  : 'bg-white border-black/10 hover:border-[#9e7d17]/60 shadow-md'
              }`}
            >
              {/* Image Asset */}
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108 group-hover:filter group-hover:brightness-90"
                loading="lazy"
                referrerPolicy="no-referrer"
              />

              {/* Default gradient overlay for text legibility */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent pointer-events-none" />

              {/* Category & AI Visual Badges */}
              <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10 pointer-events-none">
                <span className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-[10px] font-mono uppercase tracking-widest text-[#f4efe6]">
                  {item.category}
                </span>
                <span className="px-2.5 py-1 rounded-full bg-[#d4af37]/90 text-black text-[10px] font-mono font-bold tracking-wider flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" />
                  AI VISUAL
                </span>
              </div>

              {/* Bottom Metadata (Always visible on mobile & base) */}
              <div className="absolute bottom-0 left-0 right-0 p-5 z-10 transition-transform duration-300 pointer-events-none">
                <h3 className="text-base sm:text-lg font-bold text-white uppercase tracking-tight mb-1">
                  {item.title}
                </h3>
                <p className="text-xs text-[#a8a8a8] line-clamp-1 font-mono">
                  {item.promptConcept}
                </p>
                
                {/* Mobile tap indicator */}
                <div className="mt-2 sm:hidden flex items-center gap-1.5 text-xs text-[#d4af37] font-mono">
                  <Instagram className="w-3.5 h-3.5" />
                  <span>View on Instagram ↗</span>
                </div>
              </div>

              {/* Hover Experience Overlay (Desktop) */}
              <div className="absolute inset-0 bg-black/75 backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-6 text-center z-20">
                <span className="text-xs font-mono font-bold uppercase tracking-[0.25em] text-[#d4af37] mb-2">
                  AI VISUAL
                </span>
                <h4 className="text-lg font-bold text-white uppercase tracking-tight mb-4 max-w-xs">
                  {item.title}
                </h4>
                <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#d4af37] text-black font-heading font-bold text-xs uppercase tracking-wider shadow-lg shadow-[#d4af37]/20 group-hover:scale-105 transition-transform">
                  <Instagram className="w-4 h-4" />
                  <span>View on Instagram ↗</span>
                </div>
                <span className="text-[11px] font-mono text-[#8a8a8a] mt-3">
                  @hasanrazau9
                </span>
              </div>
            </a>
          ))}
        </div>

        {/* Bottom Instagram CTA Card */}
        <div
          id="ai-visuals-instagram-cta"
          className={`mt-16 rounded-3xl p-8 sm:p-12 border text-center relative overflow-hidden transition-all ${
            darkMode
              ? 'bg-gradient-to-b from-[#141414] to-[#0c0c0c] border-white/10 shadow-2xl'
              : 'bg-[#faf6ee] border-black/10 shadow-lg'
          }`}
        >
          <div className="max-w-2xl mx-auto space-y-4 relative z-10">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500/20 via-purple-500/20 to-amber-500/20 text-[#d4af37] flex items-center justify-center mx-auto border border-[#d4af37]/30">
              <Instagram className="w-6 h-6" />
            </div>

            <h3 className="text-2xl sm:text-4xl font-extrabold uppercase tracking-tight">
              SEE MORE AI WORK
            </h3>

            <p className={`text-sm sm:text-base leading-relaxed ${
              darkMode ? 'text-[#a8a8a8]' : 'text-[#555]'
            }`}>
              More AI experiments, visual concepts and creative work on Instagram.
            </p>

            <div className="pt-2">
              <a
                href={PERSONAL_INFO.contact.instagram.url}
                target="_blank"
                rel="noopener noreferrer"
                id="ai-see-more-instagram-btn"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#d4af37] text-black font-heading font-bold text-xs uppercase tracking-widest hover:bg-[#ebd383] transition-all duration-300 shadow-xl shadow-[#d4af37]/20"
              >
                <Instagram className="w-4 h-4" />
                <span>Visit @hasanrazau9 ↗</span>
              </a>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
