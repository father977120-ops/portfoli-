import React, { useState } from 'react';
import { Mail, Phone, MessageSquare, Instagram, ArrowUpRight, CheckCircle2, Send } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { ContactFormData } from '../types';

interface ContactProps {
  darkMode: boolean;
}

export const Contact: React.FC<ContactProps> = ({ darkMode }) => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    projectType: 'Brand Design',
    budgetRange: 'Flexible / Let\'s Discuss',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const projectTypes = [
    "Brand Design",
    "Graphic Design",
    "Video Editing",
    "AI Automation",
    "Prompt Engineering",
    "Website/UI",
    "Other"
  ];

  const budgetRanges = [
    "Standard / Starter",
    "Mid-Tier / Dedicated",
    "Comprehensive / Enterprise",
    "Flexible / Let's Discuss"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleSendViaWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello Hasan, my name is ${formData.name || 'a visitor'}.\nProject Type: ${formData.projectType}\nBudget: ${formData.budgetRange}\nEmail: ${formData.email}\nMessage: ${formData.message}`
    );
    window.open(`https://wa.me/919631378862?text=${text}`, '_blank');
  };

  const handleSendViaEmail = () => {
    const subject = encodeURIComponent(`Project Inquiry: ${formData.projectType} - ${formData.name}`);
    const body = encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\nProject Type: ${formData.projectType}\nBudget: ${formData.budgetRange}\n\nMessage:\n${formData.message}`
    );
    window.location.href = `mailto:hasanrazau9@gmail.com?subject=${subject}&body=${body}`;
  };

  return (
    <section
      id="contact"
      className={`py-24 border-b transition-colors relative ${
        darkMode ? 'border-white/10 bg-[#0c0c0c]' : 'border-black/10 bg-[#f4efe6]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Top Dramatic CTA Headline */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
              GET IN TOUCH
            </span>
            <div className="h-[1px] w-12 bg-[#d4af37]/40" />
          </div>

          <h2 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight uppercase leading-[1.04]">
            HAVE AN IDEA?<br />
            <span className="text-[#d4af37]">LET'S BUILD IT.</span>
          </h2>

          <p className={`text-base sm:text-lg leading-relaxed mt-4 ${
            darkMode ? 'text-[#a8a8a8]' : 'text-[#444]'
          }`}>
            Have a project, brand idea or creative challenge? Let's turn it into something real.
          </p>

          {/* Quick Trigger Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-6">
            <a
              href={PERSONAL_INFO.contact.whatsapp.url}
              target="_blank"
              rel="noopener noreferrer"
              id="cta-whatsapp-btn"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-emerald-500 text-black font-heading font-bold text-xs uppercase tracking-wider hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/10"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp Me</span>
            </a>

            <a
              href={PERSONAL_INFO.contact.email.url}
              id="cta-email-btn"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#f4efe6] text-black font-heading font-bold text-xs uppercase tracking-wider hover:bg-[#d4af37] transition-all"
            >
              <Mail className="w-4 h-4" />
              <span>Email Me</span>
            </a>

            <a
              href={PERSONAL_INFO.contact.instagram.url}
              target="_blank"
              rel="noopener noreferrer"
              id="cta-instagram-btn"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/20 text-[#f4efe6] font-heading font-medium text-xs uppercase tracking-wider hover:bg-white/5 transition-all"
            >
              <Instagram className="w-4 h-4" />
              <span>@hasanrazau9</span>
            </a>
          </div>
        </div>

        {/* 2-Column Layout: Form (7 cols) + Direct Contact Cards (5 cols) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left: Modern Contact Form */}
          <div className="lg:col-span-7">
            <div
              id="contact-form-card"
              className={`rounded-3xl p-8 sm:p-10 border shadow-2xl transition-all ${
                darkMode
                  ? 'bg-gradient-to-b from-[#141414] to-[#0a0a0a] border-white/15'
                  : 'bg-[#faf6ee] border-black/10'
              }`}
            >
              <div className="mb-6">
                <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37] block mb-1">
                  Project Inquiry Form
                </span>
                <h3 className="text-2xl font-bold tracking-tight uppercase">
                  Start a Conversation
                </h3>
              </div>

              {submitted ? (
                <div className="py-12 text-center space-y-4 animate-fadeIn">
                  <div className="w-16 h-16 rounded-full bg-[#d4af37]/20 text-[#d4af37] flex items-center justify-center mx-auto border border-[#d4af37]/40">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-2xl font-bold uppercase tracking-tight">
                    Thank You, {formData.name || 'Friend'}!
                  </h4>
                  <p className="text-sm text-[#a8a8a8] max-w-md mx-auto">
                    Your inquiry has been compiled. You can also dispatch it immediately via WhatsApp or Email for instant priority review:
                  </p>

                  <div className="flex flex-wrap justify-center gap-3 pt-4">
                    <button
                      type="button"
                      onClick={handleSendViaWhatsApp}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-emerald-500 text-black font-bold text-xs uppercase tracking-wider hover:bg-emerald-400"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Send via WhatsApp ↗</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleSendViaEmail}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#d4af37] text-black font-bold text-xs uppercase tracking-wider hover:bg-[#eccf76]"
                    >
                      <Mail className="w-4 h-4" />
                      <span>Send via Email ↗</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setSubmitted(false);
                      setFormData({
                        name: '',
                        email: '',
                        projectType: 'Brand Design',
                        budgetRange: 'Flexible / Let\'s Discuss',
                        message: ''
                      });
                    }}
                    className="text-xs font-mono text-[#8a8a8a] underline block mx-auto pt-4"
                  >
                    Submit another response
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Name */}
                    <div>
                      <label htmlFor="form-name" className="block text-xs font-mono uppercase tracking-wider text-[#8a8a8a] mb-2">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        id="form-name"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Hasan / Alex"
                        className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:border-[#d4af37] transition-colors ${
                          darkMode
                            ? 'bg-white/5 border-white/10 text-white placeholder:text-[#555]'
                            : 'bg-black/5 border-black/10 text-black placeholder:text-[#999]'
                        }`}
                      />
                    </div>

                    {/* Email */}
                    <div>
                      <label htmlFor="form-email" className="block text-xs font-mono uppercase tracking-wider text-[#8a8a8a] mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="form-email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="you@company.com"
                        className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:border-[#d4af37] transition-colors ${
                          darkMode
                            ? 'bg-white/5 border-white/10 text-white placeholder:text-[#555]'
                            : 'bg-black/5 border-black/10 text-black placeholder:text-[#999]'
                        }`}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Project Type */}
                    <div>
                      <label htmlFor="form-project-type" className="block text-xs font-mono uppercase tracking-wider text-[#8a8a8a] mb-2">
                        Project Type
                      </label>
                      <select
                        id="form-project-type"
                        value={formData.projectType}
                        onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                        className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:border-[#d4af37] transition-colors ${
                          darkMode
                            ? 'bg-[#1a1a1a] border-white/10 text-white'
                            : 'bg-white border-black/10 text-black'
                        }`}
                      >
                        {projectTypes.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Budget Range */}
                    <div>
                      <label htmlFor="form-budget" className="block text-xs font-mono uppercase tracking-wider text-[#8a8a8a] mb-2">
                        Budget Range
                      </label>
                      <select
                        id="form-budget"
                        value={formData.budgetRange}
                        onChange={(e) => setFormData({ ...formData, budgetRange: e.target.value })}
                        className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:border-[#d4af37] transition-colors ${
                          darkMode
                            ? 'bg-[#1a1a1a] border-white/10 text-white'
                            : 'bg-white border-black/10 text-black'
                        }`}
                      >
                        {budgetRanges.map((range) => (
                          <option key={range} value={range}>
                            {range}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label htmlFor="form-message" className="block text-xs font-mono uppercase tracking-wider text-[#8a8a8a] mb-2">
                      Project Details / Message *
                    </label>
                    <textarea
                      id="form-message"
                      rows={4}
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Tell me about your brand, project goals, timeline or visual references..."
                      className={`w-full px-4 py-3 rounded-xl border text-sm focus:outline-none focus:border-[#d4af37] transition-colors resize-none ${
                        darkMode
                          ? 'bg-white/5 border-white/10 text-white placeholder:text-[#555]'
                          : 'bg-black/5 border-black/10 text-black placeholder:text-[#999]'
                      }`}
                    />
                  </div>

                  {/* Submit CTA */}
                  <button
                    type="submit"
                    id="contact-form-submit-button"
                    className="w-full py-4 rounded-xl bg-[#d4af37] text-black font-heading font-bold text-xs uppercase tracking-widest hover:bg-[#edd17b] transition-all flex items-center justify-center gap-2 shadow-xl shadow-[#d4af37]/20"
                  >
                    <span>Send Inquiry</span>
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Right: Direct Contact Cards (LET'S CONNECT) */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37] block mb-1">
                Direct Contact Channels
              </span>
              <h3 className="text-2xl font-bold tracking-tight uppercase">
                LET'S CONNECT
              </h3>
              <p className={`text-xs sm:text-sm mt-1 ${darkMode ? 'text-[#8a8a8a]' : 'text-[#666]'}`}>
                Reach out directly via your preferred platform for immediate response.
              </p>
            </div>

            <div className="space-y-4" id="direct-contact-channel-cards">
              {/* WhatsApp Card */}
              <div
                className={`p-5 rounded-2xl border transition-all ${
                  darkMode ? 'bg-white/3 border-white/10' : 'bg-black/2 border-black/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-mono text-[#8a8a8a] uppercase">WhatsApp</div>
                      <div className="text-sm font-bold font-mono text-[#f4efe6]">
                        {PERSONAL_INFO.contact.whatsapp.display}
                      </div>
                    </div>
                  </div>
                  <a
                    href={PERSONAL_INFO.contact.whatsapp.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-mono uppercase tracking-wider text-emerald-400 hover:underline"
                  >
                    <span>Chat on WhatsApp</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Email Card */}
              <div
                className={`p-5 rounded-2xl border transition-all ${
                  darkMode ? 'bg-white/3 border-white/10' : 'bg-black/2 border-black/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-mono text-[#8a8a8a] uppercase">Email</div>
                      <div className="text-sm font-bold font-mono text-[#f4efe6]">
                        {PERSONAL_INFO.contact.email.address}
                      </div>
                    </div>
                  </div>
                  <a
                    href={PERSONAL_INFO.contact.email.url}
                    className="inline-flex items-center gap-1 text-xs font-mono uppercase tracking-wider text-amber-400 hover:underline"
                  >
                    <span>Send Email</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Instagram Card */}
              <div
                className={`p-5 rounded-2xl border transition-all ${
                  darkMode ? 'bg-white/3 border-white/10' : 'bg-black/2 border-black/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center">
                      <Instagram className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-mono text-[#8a8a8a] uppercase">Instagram</div>
                      <div className="text-sm font-bold font-mono text-[#f4efe6]">
                        {PERSONAL_INFO.contact.instagram.handle}
                      </div>
                    </div>
                  </div>
                  <a
                    href={PERSONAL_INFO.contact.instagram.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-mono uppercase tracking-wider text-[#d4af37] hover:underline"
                  >
                    <span>Follow on Instagram</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Phone Card */}
              <div
                className={`p-5 rounded-2xl border transition-all ${
                  darkMode ? 'bg-white/3 border-white/10' : 'bg-black/2 border-black/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-mono text-[#8a8a8a] uppercase">Phone</div>
                      <div className="text-sm font-bold font-mono text-[#f4efe6]">
                        {PERSONAL_INFO.contact.phone.display}
                      </div>
                    </div>
                  </div>
                  <a
                    href={PERSONAL_INFO.contact.phone.url}
                    className="inline-flex items-center gap-1 text-xs font-mono uppercase tracking-wider text-blue-400 hover:underline"
                  >
                    <span>Call Me</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Note confirming verified contact only */}
            <div className="p-4 rounded-xl border border-white/5 bg-white/2 text-[11px] font-mono text-[#7a7a7a]">
              🔒 Strictly official contact channels: Instagram, WhatsApp, Email &amp; Direct Phone.
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
