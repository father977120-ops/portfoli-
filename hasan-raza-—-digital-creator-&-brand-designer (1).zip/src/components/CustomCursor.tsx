import React, { useEffect, useState } from 'react';

export const CustomCursor: React.FC = () => {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [isPointer, setIsPointer] = useState(false);
  const [cursorText, setCursorText] = useState<string | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  useEffect(() => {
    // Check if touch device
    if (window.matchMedia('(pointer: coarse)').matches) {
      setIsTouchDevice(true);
      return;
    }

    const onMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);

      const target = e.target as HTMLElement | null;
      if (!target) return;

      const cursorTarget = target.closest('[data-cursor]');
      if (cursorTarget) {
        const type = cursorTarget.getAttribute('data-cursor');
        setCursorText(type === 'view' ? 'VIEW ↗' : type === 'open' ? 'OPEN' : type);
        setIsPointer(true);
      } else {
        setCursorText(null);
        const clickable = target.closest('a, button, input, textarea, select, [role="button"]');
        setIsPointer(!!clickable);
      }
    };

    const onMouseLeave = () => setIsVisible(false);
    const onMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseleave', onMouseLeave);
    document.addEventListener('mouseenter', onMouseEnter);

    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseleave', onMouseLeave);
      document.removeEventListener('mouseenter', onMouseEnter);
    };
  }, [isVisible]);

  if (isTouchDevice || !isVisible) return null;

  return (
    <div
      id="custom-cursor-container"
      className="fixed inset-0 pointer-events-none z-999 overflow-hidden transition-opacity duration-300"
      aria-hidden="true"
    >
      <div
        className={`fixed top-0 left-0 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none transition-transform duration-100 ease-out flex items-center justify-center font-heading text-[10px] font-bold tracking-wider select-none ${
          cursorText
            ? 'w-16 h-16 bg-[#d4af37] text-black shadow-lg shadow-[#d4af37]/30 scale-100'
            : isPointer
            ? 'w-10 h-10 border border-[#d4af37]/80 bg-[#d4af37]/10 scale-100'
            : 'w-3 h-3 bg-[#f4efe6] scale-100'
        }`}
        style={{
          transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
        }}
      >
        {cursorText && (
          <span className="animate-pulse">{cursorText}</span>
        )}
      </div>
    </div>
  );
};
