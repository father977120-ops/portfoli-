import React from 'react';
import { ArrowUpRight, FolderOpen, ExternalLink, Globe } from 'lucide-react';
import { Project } from '../types';
import { PROJECTS } from '../data/portfolioData';

interface FeaturedWorkProps {
  onSelectProject: (project: Project) => void;
  darkMode: boolean;
}

export const FeaturedWork: React.FC<FeaturedWorkProps> = ({ onSelectProject, darkMode }) => {
  return (
    <section
      id="work"
      className={`py-24 border-b transition-colors ${
        darkMode ? 'border-white/10 bg-[#0c0c0c]' : 'border-black/10 bg-[#f4efe6]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
                03 / SELECTED WORK
              </span>
              <div className="h-[1px] w-12 bg-[#d4af37]/40" />
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight uppercase leading-[1.08]">
              PROJECTS<br />
              <span className="text-[#d4af37]">I'M PROUD OF.</span>
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-[#8a8a8a] uppercase tracking-wider">
              {PROJECTS.length} Curated Case Studies
            </span>
            <div className="w-2 h-2 rounded-full bg-[#d4af37]" />
          </div>
        </div>

        {/* Projects Grid / Editorial Masonry */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROJECTS.map((project, idx) => (
            <div
              key={project.id}
              onClick={() => onSelectProject(project)}
              data-cursor="view"
              className={`group cursor-pointer rounded-3xl overflow-hidden border transition-all duration-300 flex flex-col justify-between ${
                darkMode
                  ? 'bg-gradient-to-b from-[#141414] to-[#0a0a0a] border-white/10 hover:border-[#d4af37]/50 shadow-xl shadow-black/40 hover:-translate-y-1.5'
                  : 'bg-[#faf6ee] border-black/10 hover:border-[#9e7d17]/50 shadow-md hover:-translate-y-1.5'
              }`}
            >
              {/* Image Container */}
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-black/60">
                <img
                  src={project.coverImage}
                  alt={project.name}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-70 group-hover:opacity-40 transition-opacity" />
                
                {/* Year Pill & Category Badge */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-[11px] font-mono text-white font-semibold">
                      {project.year}
                    </span>
                    {project.liveUrl && (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-500/90 text-black text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1 shadow-md">
                        <span className="w-1.5 h-1.5 rounded-full bg-black animate-pulse" />
                        LIVE SITE
                      </span>
                    )}
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-[10px] font-mono uppercase text-[#d4af37] tracking-wider">
                    {project.category.split('•')[0].trim()}
                  </span>
                </div>

                {/* Hover overlay hint */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40 backdrop-blur-xs">
                  <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#d4af37] text-black font-heading font-bold text-xs uppercase tracking-wider shadow-lg">
                    <span>View Case Study</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>

              {/* Card Meta Content */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[11px] font-mono uppercase tracking-widest text-[#d4af37]">
                      0{idx + 1} // PROJECT
                    </span>
                    <span className="text-[11px] font-mono text-[#8a8a8a]">
                      {project.toolsUsed.slice(0, 2).join(' • ')}
                    </span>
                  </div>

                  <h3 className="font-heading text-xl sm:text-2xl font-bold tracking-tight mb-2 uppercase group-hover:text-[#d4af37] transition-colors">
                    {project.name}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#8a8a8a] line-clamp-2 leading-relaxed mb-4">
                    {project.shortDescription}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs gap-2">
                  {project.liveUrl ? (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="inline-flex items-center gap-1.5 font-mono text-xs text-emerald-400 hover:text-emerald-300 transition-colors font-semibold"
                    >
                      <Globe className="w-3.5 h-3.5" />
                      <span>Visit Live App ↗</span>
                    </a>
                  ) : (
                    <span className="font-mono text-[#7a7a7a] truncate max-w-[200px]">
                      {project.category}
                    </span>
                  )}

                  <button
                    type="button"
                    className="inline-flex items-center gap-1 font-heading font-semibold uppercase text-[#f4efe6] group-hover:text-[#d4af37] transition-colors shrink-0"
                  >
                    <span>Details</span>
                    <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
