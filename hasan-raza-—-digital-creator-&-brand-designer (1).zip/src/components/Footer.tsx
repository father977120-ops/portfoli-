import React from 'react';
import { ArrowUp, Instagram, MessageSquare, Mail, Phone } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface FooterProps {
  darkMode: boolean;
}

export const Footer: React.FC<FooterProps> = ({ darkMode }) => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer
      id="main-portfolio-footer"
      className={`pt-16 pb-12 transition-colors ${
        darkMode ? 'bg-[#080808] text-[#f4efe6]' : 'bg-[#e5dfd3] text-[#0c0c0c]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Main Footer Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8 pb-12 border-b border-white/10">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-7 h-7 rounded-lg bg-[#d4af37] text-black font-heading font-black text-xs flex items-center justify-center">
                HR
              </div>
              <h3 className="font-heading text-2xl font-bold tracking-tight uppercase">
                {PERSONAL_INFO.name}
              </h3>
            </div>
            <p className="text-xs font-mono text-[#8a8a8a] tracking-wider uppercase">
              Digital Creator • Brand Designer • AI Creative
            </p>
          </div>

          {/* Quick Contact Shortcuts */}
          <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
            <a
              href={PERSONAL_INFO.contact.instagram.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-[#8a8a8a] hover:text-[#d4af37] transition-colors"
            >
              <Instagram className="w-3.5 h-3.5" />
              <span>Instagram</span>
            </a>
            <span className="text-white/20">|</span>
            <a
              href={PERSONAL_INFO.contact.whatsapp.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-[#8a8a8a] hover:text-emerald-400 transition-colors"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
            <span className="text-white/20">|</span>
            <a
              href={PERSONAL_INFO.contact.email.url}
              className="flex items-center gap-1.5 text-[#8a8a8a] hover:text-amber-400 transition-colors"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Email</span>
            </a>
            <span className="text-white/20">|</span>
            <a
              href={PERSONAL_INFO.contact.phone.url}
              className="flex items-center gap-1.5 text-[#8a8a8a] hover:text-blue-400 transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call</span>
            </a>
          </div>

          {/* Back to top button */}
          <button
            type="button"
            onClick={scrollToTop}
            id="footer-back-to-top"
            aria-label="Scroll back to top"
            className="p-3 rounded-full border border-white/10 hover:bg-white/10 hover:border-[#d4af37]/50 transition-all flex items-center justify-center group"
          >
            <ArrowUp className="w-4 h-4 text-[#d4af37] group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

        {/* Middle Details */}
        <div className="py-8 grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs border-b border-white/10">
          <div>
            <span className="font-mono text-[#7a7a7a] uppercase block mb-1">Instagram</span>
            <a
              href={PERSONAL_INFO.contact.instagram.url}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-[#f4efe6] hover:text-[#d4af37] transition-colors"
            >
              {PERSONAL_INFO.contact.instagram.handle}
            </a>
          </div>

          <div>
            <span className="font-mono text-[#7a7a7a] uppercase block mb-1">Email</span>
            <a
              href={PERSONAL_INFO.contact.email.url}
              className="font-medium text-[#f4efe6] hover:text-[#d4af37] transition-colors"
            >
              {PERSONAL_INFO.contact.email.address}
            </a>
          </div>

          <div>
            <span className="font-mono text-[#7a7a7a] uppercase block mb-1">WhatsApp</span>
            <a
              href={PERSONAL_INFO.contact.whatsapp.url}
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-[#f4efe6] hover:text-[#d4af37] transition-colors"
            >
              {PERSONAL_INFO.contact.whatsapp.display}
            </a>
          </div>
        </div>

        {/* Bottom Copyright & Built With Line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-[#7a7a7a]">
          <div>
            © 2026 {PERSONAL_INFO.name}. All rights reserved.
          </div>
          <div>
            Designed &amp; built with creativity + technology.
          </div>
        </div>

      </div>
    </footer>
  );
};
