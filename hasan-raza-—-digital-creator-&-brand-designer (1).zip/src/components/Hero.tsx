import React, { useState } from 'react';
import { ArrowUpRight, Sparkles, Play, Camera, Compass, Layers, Cpu, Eye } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface HeroProps {
  darkMode: boolean;
}

export const Hero: React.FC<HeroProps> = ({ darkMode }) => {
  const [activeTab, setActiveTab] = useState<'design' | 'create' | 'automate'>('design');

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const topOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center pt-28 pb-16 overflow-hidden border-b border-white/10"
    >
      {/* Ambient background glow & subtle design grid */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <div
          className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, ${darkMode ? '#ffffff' : '#000000'} 1px, transparent 0)`,
            backgroundSize: '32px 32px'
          }}
        />
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute bottom-1/3 left-1/10 w-80 h-80 bg-slate-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      <div className="max-w-7xl mx-auto px-6 sm:px-8 w-full relative z-10 my-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Typography & CTAs (7 cols) */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6">
            
            {/* Badges row: Small label & Animated AI Creative badge & Availability */}
            <div className="flex flex-wrap items-center gap-3">
              <span className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-mono font-medium tracking-wider uppercase border ${
                darkMode
                  ? 'bg-white/5 border-white/10 text-[#d4af37]'
                  : 'bg-black/5 border-black/10 text-[#9e7d17]'
              }`}>
                <span className="w-2 h-2 rounded-full bg-[#d4af37]" />
                HASAN RAZA / DIGITAL CREATOR
              </span>

              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono font-semibold tracking-wider bg-gradient-to-r from-[#d4af37]/20 to-amber-500/20 border border-[#d4af37]/40 text-[#f4efe6]">
                <Sparkles className="w-3.5 h-3.5 text-[#d4af37] animate-spin" style={{ animationDuration: '8s' }} />
                ✦ AI CREATIVE
              </span>

              <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono text-[#8a8a8a] border border-white/5 bg-white/2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                Available for selected projects
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tighter leading-[1.05] uppercase">
              <span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#f4efe6] to-[#b3ada4]">
                I TURN IDEAS INTO
              </span>
              <span className="block text-[#f4efe6] relative mt-1">
                DIGITAL EXPERIENCES<span className="text-[#d4af37]">.</span>
              </span>
            </h1>

            {/* Supporting text */}
            <p className={`text-lg sm:text-xl font-normal max-w-2xl leading-relaxed ${
              darkMode ? 'text-[#a8a8a8]' : 'text-[#4a4a4a]'
            }`}>
              {PERSONAL_INFO.aboutHero}
            </p>

            {/* Specialties Pill Bar */}
            <div className="w-full pt-1">
              <div className="text-[11px] uppercase tracking-widest font-mono text-[#7a7a7a] mb-2.5">
                Core Specialties
              </div>
              <div className="flex flex-wrap gap-2">
                {PERSONAL_INFO.specialties.map((spec) => (
                  <span
                    key={spec}
                    className={`text-xs px-3 py-1.5 rounded-md font-medium tracking-wide border transition-all ${
                      darkMode
                        ? 'border-white/10 bg-white/3 text-[#dcd6cb] hover:border-[#d4af37]/40'
                        : 'border-black/10 bg-black/3 text-[#2a2a2a] hover:border-[#9e7d17]/40'
                    }`}
                  >
                    {spec}
                  </span>
                ))}
              </div>
            </div>

            {/* CTAs Row */}
            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button
                type="button"
                onClick={() => scrollToSection('work')}
                id="hero-primary-cta"
                data-cursor="view"
                className="group relative inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-[#f4efe6] text-black font-heading font-bold text-sm tracking-wider uppercase hover:bg-[#d4af37] transition-all duration-300 shadow-xl shadow-black/30"
              >
                <span>View My Work</span>
                <ArrowUpRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('contact')}
                id="hero-secondary-cta"
                className={`inline-flex items-center gap-2 px-6 py-3.5 rounded-full text-sm font-heading font-medium tracking-wider uppercase border transition-all duration-300 ${
                  darkMode
                    ? 'border-white/20 text-[#f4efe6] hover:bg-white/10 hover:border-white/40'
                    : 'border-black/20 text-[#0c0c0c] hover:bg-black/5 hover:border-black/40'
                }`}
              >
                <span>Let's Collaborate</span>
              </button>

              <a
                href={PERSONAL_INFO.contact.whatsapp.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-xs font-mono text-[#8a8a8a] hover:text-[#d4af37] px-2 py-2 transition-colors"
                id="hero-whatsapp-quick"
              >
                <span>WhatsApp: {PERSONAL_INFO.contact.whatsapp.display}</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Right Column: Creative-Tech Composition (5 cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md w-full aspect-square rounded-3xl p-6 border border-white/15 bg-gradient-to-b from-white/10 to-white/2 backdrop-blur-xl shadow-2xl overflow-hidden group">
              
              {/* Outer Decorative Grid & Viewfinder markings */}
              <div className="absolute top-3 left-3 text-[10px] font-mono text-[#7a7a7a] flex items-center gap-2">
                <span className="w-2 h-2 border-t-2 border-l-2 border-[#d4af37]"></span>
                <span>REC // 4K 60FPS</span>
              </div>
              <div className="absolute top-3 right-3 text-[10px] font-mono text-[#7a7a7a] flex items-center gap-2">
                <span>AI_ENGINE: V2.6</span>
                <span className="w-2 h-2 border-t-2 border-r-2 border-[#d4af37]"></span>
              </div>
              <div className="absolute bottom-3 left-3 text-[10px] font-mono text-[#7a7a7a]">
                <span className="w-2 h-2 border-b-2 border-l-2 border-[#d4af37] block"></span>
              </div>
              <div className="absolute bottom-3 right-3 text-[10px] font-mono text-[#7a7a7a]">
                <span className="w-2 h-2 border-b-2 border-r-2 border-[#d4af37] block"></span>
              </div>

              {/* Central Camera Lens / Neural Visualizer */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-64 h-64 rounded-full border border-white/10 flex items-center justify-center animate-spin" style={{ animationDuration: '40s' }}>
                  <div className="w-48 h-48 rounded-full border border-dashed border-[#d4af37]/30 flex items-center justify-center">
                    <div className="w-32 h-32 rounded-full bg-gradient-to-tr from-[#d4af37]/20 via-transparent to-purple-500/10 blur-md" />
                  </div>
                </div>
              </div>

              {/* Composition Content: Interactive Trinity Switcher */}
              <div className="relative z-10 h-full flex flex-col justify-between">
                
                {/* Top Interactive Tabs: DESIGN / CREATE / AUTOMATE */}
                <div className="flex items-center justify-between bg-black/40 p-1.5 rounded-xl border border-white/10">
                  <button
                    type="button"
                    onClick={() => setActiveTab('design')}
                    className={`flex-1 py-2 text-xs font-mono font-bold tracking-wider rounded-lg transition-all ${
                      activeTab === 'design'
                        ? 'bg-[#d4af37] text-black shadow-md'
                        : 'text-[#a8a8a8] hover:text-white'
                    }`}
                  >
                    DESIGN
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('create')}
                    className={`flex-1 py-2 text-xs font-mono font-bold tracking-wider rounded-lg transition-all ${
                      activeTab === 'create'
                        ? 'bg-[#d4af37] text-black shadow-md'
                        : 'text-[#a8a8a8] hover:text-white'
                    }`}
                  >
                    CREATE
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('automate')}
                    className={`flex-1 py-2 text-xs font-mono font-bold tracking-wider rounded-lg transition-all ${
                      activeTab === 'automate'
                        ? 'bg-[#d4af37] text-black shadow-md'
                        : 'text-[#a8a8a8] hover:text-white'
                    }`}
                  >
                    AUTOMATE
                  </button>
                </div>

                {/* Dynamic Visual Card according to active tab */}
                <div className="my-auto py-4">
                  {activeTab === 'design' && (
                    <div className="space-y-3 animate-fadeIn">
                      <div className="flex items-center gap-3 p-3 rounded-2xl bg-black/60 border border-white/10">
                        <div className="p-2.5 rounded-xl bg-[#d4af37]/20 text-[#d4af37]">
                          <Layers className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-xs font-mono text-[#8a8a8a] uppercase">Identity &amp; Layout</div>
                          <div className="text-sm font-bold text-white">Brand Typography &amp; UI Systems</div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                          <span className="text-[#8a8a8a] block text-[10px]">Grid Ratio</span>
                          <span className="text-white font-bold">1.618 Golden</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                          <span className="text-[#8a8a8a] block text-[10px]">Kerning Fidelity</span>
                          <span className="text-emerald-400 font-bold">Optical 100%</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeTab === 'create' && (
                    <div className="space-y-3 animate-fadeIn">
                      <div className="flex items-center gap-3 p-3 rounded-2xl bg-black/60 border border-white/10">
                        <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400">
                          <Camera className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-xs font-mono text-[#8a8a8a] uppercase">Cinematic Video &amp; Lens</div>
                          <div className="text-sm font-bold text-white">4K Dynamic Storytelling</div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 border border-white/5 text-xs font-mono">
                        <span className="text-[#8a8a8a]">Frame Rhythm</span>
                        <span className="flex items-center gap-1.5 text-white">
                          <Play className="w-3 h-3 fill-white" /> 24 / 60 FPS
                        </span>
                      </div>
                    </div>
                  )}

                  {activeTab === 'automate' && (
                    <div className="space-y-3 animate-fadeIn">
                      <div className="flex items-center gap-3 p-3 rounded-2xl bg-black/60 border border-white/10">
                        <div className="p-2.5 rounded-xl bg-purple-500/20 text-purple-300">
                          <Cpu className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-xs font-mono text-[#8a8a8a] uppercase">Prompt &amp; Model Logic</div>
                          <div className="text-sm font-bold text-white">Generative Vision Workflows</div>
                        </div>
                      </div>
                      <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-[11px] font-mono text-purple-200">
                        &gt; Synthesizing lighting vectors &amp; aspect ratios...
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Tech Micro Card */}
                <div className="pt-3 border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-[#8a8a8a]">
                  <span className="flex items-center gap-1.5">
                    <Eye className="w-3.5 h-3.5 text-[#d4af37]" />
                    Human Taste + AI Power
                  </span>
                  <span className="text-white font-semibold tracking-wider">CREATIVE STUDIO</span>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
