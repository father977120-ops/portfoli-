import React from 'react';

interface MarqueeProps {
  darkMode: boolean;
}

export const Marquee: React.FC<MarqueeProps> = ({ darkMode }) => {
  const marqueeItems = [
    "BRAND DESIGN",
    "VIDEO EDITING",
    "AI AUTOMATION",
    "PROMPT ENGINEERING",
    "UI/UX",
    "DIGITAL CONTENT",
    "AI VISUAL CREATION",
  ];

  return (
    <div
      id="brand-marquee-strip"
      className={`relative w-full overflow-hidden py-5 border-y transition-colors select-none ${
        darkMode
          ? 'bg-[#0f0f0f] border-white/10 text-[#f4efe6]'
          : 'bg-[#ebe5da] border-black/10 text-[#0c0c0c]'
      }`}
    >
      <div className="flex w-max animate-marquee">
        {/* Repeating sequence for continuous smooth loop */}
        {[...Array(4)].map((_, loopIndex) => (
          <div key={loopIndex} className="flex items-center shrink-0">
            {marqueeItems.map((item, itemIndex) => (
              <div key={`${loopIndex}-${itemIndex}`} className="flex items-center">
                <span className="font-heading font-extrabold text-sm sm:text-base tracking-[0.2em] uppercase px-4 sm:px-6 hover:text-[#d4af37] transition-colors">
                  {item}
                </span>
                <span className="text-[#d4af37] text-xs font-mono select-none">✦</span>
              </div>
            ))}
          </div>
        ))}
      </div>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0%); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 28s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
};
