import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Sun, Moon, Volume2, VolumeX } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenContactModal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ darkMode, setDarkMode, soundEnabled, onToggleSound }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: "Home", href: "#hero" },
    { name: "About", href: "#about" },
    { name: "Services", href: "#services" },
    { name: "Work", href: "#work" },
    { name: "AI Work", href: "#ai-visuals" },
    { name: "Skills", href: "#skills" },
    { name: "Process", href: "#process" },
    { name: "Contact", href: "#contact" },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      const topOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <header
      id="main-navigation-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? darkMode
            ? 'bg-[#0c0c0c]/85 backdrop-blur-md border-b border-white/10 shadow-lg shadow-black/40 py-3.5'
            : 'bg-[#f4efe6]/90 backdrop-blur-md border-b border-black/10 shadow-sm py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between">
        {/* Left: Brand Identity */}
        <a
          href="#hero"
          onClick={(e) => handleLinkClick(e, '#hero')}
          className="group flex items-center gap-3"
          id="nav-brand-logo"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#d4af37] to-[#b38f20] text-black font-heading font-black text-sm flex items-center justify-center tracking-tighter shadow-sm transition-transform duration-300 group-hover:scale-105">
            HR
          </div>
          <div className="flex flex-col">
            <span className={`font-heading font-bold text-base tracking-tight transition-colors ${
              darkMode ? 'text-[#f4efe6] group-hover:text-[#d4af37]' : 'text-[#0c0c0c] group-hover:text-[#9e7d17]'
            }`}>
              {PERSONAL_INFO.name}
            </span>
            <span className="text-[10px] uppercase tracking-widest text-[#8a8a8a] flex items-center gap-1.5 font-mono">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Available
            </span>
          </div>
        </a>

        {/* Center: Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2 px-3 py-1.5 rounded-full border border-white/10 bg-white/5 backdrop-blur-md" id="desktop-navigation-links">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={(e) => handleLinkClick(e, link.href)}
              className={`text-xs font-medium uppercase tracking-wider px-3 py-1.5 rounded-full transition-all duration-200 ${
                link.name === 'AI Work'
                  ? darkMode
                    ? 'text-[#d4af37] hover:bg-[#d4af37]/10'
                    : 'text-[#9e7d17] hover:bg-[#9e7d17]/10'
                  : darkMode
                  ? 'text-[#a8a8a8] hover:text-[#f4efe6] hover:bg-white/5'
                  : 'text-[#4a4a4a] hover:text-[#0c0c0c] hover:bg-black/5'
              }`}
            >
              {link.name}
              {link.name === 'AI Work' && <span className="ml-1 text-[9px] text-[#d4af37]">✦</span>}
            </a>
          ))}
        </nav>

        {/* Right: Theme Toggle, Sound Toggle & CTA */}
        <div className="hidden md:flex items-center gap-3" id="nav-actions-right">
          {/* Sound Effects Toggle */}
          <button
            type="button"
            onClick={onToggleSound}
            id="sound-toggle-button"
            aria-label={soundEnabled ? "Disable interaction sound cues" : "Enable interaction sound cues"}
            title={soundEnabled ? "Sound Effects: ON (Click to mute cues)" : "Sound Effects: OFF (Click to enable cues)"}
            className={`relative p-2 rounded-full border transition-all duration-200 flex items-center justify-center ${
              soundEnabled
                ? darkMode
                  ? 'border-[#d4af37]/50 bg-[#d4af37]/15 text-[#d4af37] shadow-sm shadow-[#d4af37]/20'
                  : 'border-[#9e7d17]/50 bg-[#9e7d17]/15 text-[#9e7d17]'
                : darkMode
                ? 'border-white/10 bg-white/5 text-[#8a8a8a] hover:text-[#f4efe6] hover:bg-white/10'
                : 'border-black/10 bg-black/5 text-[#666666] hover:text-[#0c0c0c] hover:bg-black/10'
            }`}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-[#d4af37]" />
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#d4af37]" />
                <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#d4af37] animate-ping opacity-60" />
              </>
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>

          {/* Theme Switcher */}
          <button
            type="button"
            onClick={() => setDarkMode(!darkMode)}
            id="theme-toggle-button"
            aria-label="Toggle theme mode"
            className={`p-2 rounded-full border transition-all duration-200 ${
              darkMode
                ? 'border-white/10 bg-white/5 text-[#f4efe6] hover:bg-white/10'
                : 'border-black/10 bg-black/5 text-[#0c0c0c] hover:bg-black/10'
            }`}
          >
            {darkMode ? <Sun className="w-4 h-4 text-[#d4af37]" /> : <Moon className="w-4 h-4 text-[#4a4a4a]" />}
          </button>

          {/* Let's Talk CTA */}
          <a
            href="#contact"
            onClick={(e) => handleLinkClick(e, '#contact')}
            id="nav-cta-talk-button"
            className="group inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold px-4 py-2.5 rounded-full bg-[#f4efe6] text-black hover:bg-[#d4af37] transition-all duration-300 shadow-sm"
          >
            <span>Let's Talk</span>
            <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>

        {/* Mobile Hamburger & Controls Button */}
        <div className="flex md:hidden items-center gap-2">
          {/* Mobile Sound Toggle */}
          <button
            type="button"
            onClick={onToggleSound}
            id="mobile-sound-toggle-button"
            className={`relative p-2 rounded-full border transition-colors ${
              soundEnabled
                ? darkMode
                  ? 'border-[#d4af37]/50 bg-[#d4af37]/15 text-[#d4af37]'
                  : 'border-[#9e7d17]/50 bg-[#9e7d17]/15 text-[#9e7d17]'
                : darkMode
                ? 'border-white/10 bg-white/5 text-[#8a8a8a]'
                : 'border-black/10 bg-black/5 text-[#666666]'
            }`}
            aria-label={soundEnabled ? "Disable sound effects" : "Enable sound effects"}
            title={soundEnabled ? "Sound: ON" : "Sound: OFF"}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-[#d4af37]" />
                <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-[#d4af37]" />
              </>
            ) : (
              <VolumeX className="w-4 h-4" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-full border ${
              darkMode ? 'border-white/10 bg-white/5 text-[#f4efe6]' : 'border-black/10 bg-black/5 text-[#0c0c0c]'
            }`}
            aria-label="Toggle theme"
          >
            {darkMode ? <Sun className="w-4 h-4 text-[#d4af37]" /> : <Moon className="w-4 h-4" />}
          </button>
          
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            id="mobile-menu-toggle"
            aria-label="Toggle Navigation Menu"
            className={`p-2.5 rounded-xl border transition-colors ${
              darkMode ? 'border-white/15 bg-white/5 text-white' : 'border-black/15 bg-black/5 text-black'
            }`}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className={`md:hidden fixed inset-x-0 top-[60px] p-6 border-b transition-all duration-300 shadow-2xl ${
            darkMode
              ? 'bg-[#0c0c0c]/98 border-white/10 text-white'
              : 'bg-[#f4efe6]/98 border-black/10 text-[#0c0c0c]'
          }`}
        >
          <div className="flex flex-col gap-3 py-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className={`flex items-center justify-between text-base font-medium py-2.5 px-3 rounded-lg transition-colors ${
                  darkMode ? 'hover:bg-white/5' : 'hover:bg-black/5'
                }`}
              >
                <span>{link.name}</span>
                <span className="text-xs text-[#8a8a8a]">↗</span>
              </a>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-white/10 flex flex-col gap-3">
            {/* Mobile Sound Control Tile */}
            <div className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${
              darkMode ? 'border-white/10 bg-white/5' : 'border-black/10 bg-black/5'
            }`}>
              <div className="flex items-center gap-2.5">
                <div className={`p-1.5 rounded-lg ${
                  soundEnabled ? 'bg-[#d4af37]/20 text-[#d4af37]' : 'bg-white/5 text-[#8a8a8a]'
                }`}>
                  {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </div>
                <div>
                  <div className="text-xs font-heading font-bold uppercase tracking-wider">Interaction Cues</div>
                  <div className="text-[11px] text-[#8a8a8a]">{soundEnabled ? "Ambient sound on" : "Muted"}</div>
                </div>
              </div>
              <button
                type="button"
                onClick={onToggleSound}
                className={`px-3 py-1 rounded-full text-xs font-mono font-bold uppercase tracking-wider transition-all ${
                  soundEnabled
                    ? 'bg-[#d4af37] text-black shadow-sm'
                    : darkMode ? 'bg-white/10 text-[#8a8a8a]' : 'bg-black/10 text-[#666]'
                }`}
              >
                {soundEnabled ? 'ON' : 'OFF'}
              </button>
            </div>

            <a
              href="#contact"
              onClick={(e) => handleLinkClick(e, '#contact')}
              className="w-full text-center py-3 rounded-xl bg-[#d4af37] text-black font-semibold uppercase tracking-wider text-xs flex items-center justify-center gap-2"
            >
              <span>Let's Talk</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>

            <div className="flex items-center justify-between text-xs text-[#8a8a8a] pt-2 px-1">
              <span>Instagram: @hasanrazau9</span>
              <span>WhatsApp: +91 9631378862</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
