import React, { useState } from 'react';
import { Compass, Lightbulb, PenTool, Sparkles, Send, ArrowRight } from 'lucide-react';
import { PROCESS_STEPS } from '../data/portfolioData';

interface ProcessProps {
  darkMode: boolean;
}

export const Process: React.FC<ProcessProps> = ({ darkMode }) => {
  const [activeStep, setActiveStep] = useState(0);

  const getStepIcon = (idx: number) => {
    switch (idx) {
      case 0: return <Compass className="w-5 h-5" />;
      case 1: return <Lightbulb className="w-5 h-5" />;
      case 2: return <PenTool className="w-5 h-5" />;
      case 3: return <Sparkles className="w-5 h-5" />;
      case 4: return <Send className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  return (
    <section
      id="process"
      className={`py-24 border-b transition-colors ${
        darkMode ? 'border-white/10 bg-[#0f0f0f]' : 'border-black/10 bg-[#ebe5da]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
                05 / PROCESS
              </span>
              <div className="h-[1px] w-12 bg-[#d4af37]/40" />
            </div>
            
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight uppercase leading-[1.08]">
              FROM IDEA<br />
              <span className="text-[#d4af37]">TO EXECUTION.</span>
            </h2>
          </div>

          <p className={`max-w-md text-sm sm:text-base ${
            darkMode ? 'text-[#a8a8a8]' : 'text-[#555]'
          }`}>
            A proven 5-step creative framework ensuring every project moves with speed, structural precision, and distinctive visual character.
          </p>
        </div>

        {/* Horizontal Process Steps Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-10">
          {PROCESS_STEPS.map((step, idx) => (
            <button
              key={step.step}
              type="button"
              onClick={() => setActiveStep(idx)}
              className={`p-4 rounded-2xl border text-left transition-all duration-300 flex flex-col justify-between ${
                activeStep === idx
                  ? 'bg-[#d4af37] text-black border-[#d4af37] shadow-lg shadow-[#d4af37]/15 scale-[1.02]'
                  : darkMode
                  ? 'bg-white/3 border-white/10 text-[#f4efe6] hover:bg-white/5'
                  : 'bg-black/3 border-black/10 text-black hover:bg-black/5'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="font-mono text-xs font-bold">
                  {step.step}
                </span>
                <div className={activeStep === idx ? 'text-black' : 'text-[#d4af37]'}>
                  {getStepIcon(idx)}
                </div>
              </div>
              <div>
                <div className="text-xs font-bold tracking-wider uppercase">
                  {step.title}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Active Step Detailed View */}
        <div
          className={`rounded-3xl p-8 sm:p-12 border transition-all duration-300 relative overflow-hidden ${
            darkMode
              ? 'bg-gradient-to-b from-[#141414] to-[#0a0a0a] border-white/10'
              : 'bg-[#faf6ee] border-black/10'
          }`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <div className="flex items-center gap-3">
                <span className="px-3 py-1 rounded-full bg-[#d4af37] text-black font-mono font-bold text-xs">
                  STAGE {PROCESS_STEPS[activeStep].step}
                </span>
                <span className="text-xs font-mono uppercase tracking-widest text-[#8a8a8a]">
                  Execution Protocol
                </span>
              </div>

              <h3 className="text-2xl sm:text-4xl font-extrabold uppercase tracking-tight">
                {PROCESS_STEPS[activeStep].title} — {PROCESS_STEPS[activeStep].description}
              </h3>

              <p className={`text-sm sm:text-base leading-relaxed ${
                darkMode ? 'text-[#c2bcaf]' : 'text-[#444]'
              }`}>
                {PROCESS_STEPS[activeStep].details}
              </p>
            </div>

            <div className="lg:col-span-4 flex flex-col justify-center items-start lg:items-end">
              <div className="p-6 rounded-2xl border border-white/10 bg-white/2 w-full space-y-3">
                <span className="text-xs font-mono uppercase tracking-wider text-[#d4af37] block">
                  Next Progression
                </span>
                <div className="text-sm font-bold uppercase">
                  {activeStep < PROCESS_STEPS.length - 1
                    ? `0${activeStep + 2} // ${PROCESS_STEPS[activeStep + 1].title}`
                    : "01 // DISCOVER (New Cycle)"}
                </div>
                <button
                  type="button"
                  onClick={() => setActiveStep((prev) => (prev + 1) % PROCESS_STEPS.length)}
                  className="inline-flex items-center gap-2 text-xs font-mono uppercase text-[#d4af37] hover:underline pt-1"
                >
                  <span>Advance Stage</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
