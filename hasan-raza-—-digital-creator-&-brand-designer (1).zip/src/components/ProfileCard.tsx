import React from 'react';
import { Mail, Phone, MessageSquare, Instagram, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface ProfileCardProps {
  darkMode: boolean;
}

export const ProfileCard: React.FC<ProfileCardProps> = ({ darkMode }) => {
  return (
    <div
      id="hasan-raza-profile-card"
      className={`relative rounded-3xl p-6 sm:p-8 border transition-all duration-300 shadow-xl ${
        darkMode
          ? 'bg-gradient-to-b from-[#141414] to-[#0c0c0c] border-white/15 shadow-black/60'
          : 'bg-[#faf6ee] border-black/10 shadow-stone-200'
      }`}
    >
      {/* Decorative Corner Accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#d4af37]/15 to-transparent rounded-tr-3xl pointer-events-none" />

      {/* Header with Avatar & Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#111] via-[#1a1a1a] to-[#242424] border border-[#d4af37]/40 flex items-center justify-center text-[#f4efe6] font-heading font-black text-2xl shadow-inner relative overflow-hidden">
            <span className="relative z-10 text-[#d4af37]">HR</span>
            <div className="absolute inset-0 bg-[radial-gradient(#d4af37_1px,transparent_1px)] opacity-20 [background-size:8px_8px]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-heading text-xl sm:text-2xl font-bold tracking-tight text-[#f4efe6]">
                {PERSONAL_INFO.name}
              </h3>
              <span title="Verified Profile" className="text-[#d4af37]">
                <CheckCircle2 className="w-4 h-4 fill-[#d4af37]/20" />
              </span>
            </div>
            <p className="text-xs sm:text-sm font-medium text-[#d4af37] tracking-wide mt-0.5">
              {PERSONAL_INFO.primaryTitle}
            </p>
          </div>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono border border-emerald-500/30 bg-emerald-500/10 text-emerald-400">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          Active Creator
        </div>
      </div>

      {/* Specialties List */}
      <div className="py-6 border-b border-white/10">
        <div className="text-[11px] font-mono uppercase tracking-widest text-[#7a7a7a] mb-3">
          Specialties &amp; Capabilities
        </div>
        <div className="flex flex-wrap gap-2">
          {PERSONAL_INFO.allSpecialties.map((item) => (
            <span
              key={item}
              className={`text-xs px-3 py-1 rounded-md font-medium tracking-wide border ${
                darkMode
                  ? 'bg-white/5 border-white/10 text-[#f4efe6]'
                  : 'bg-black/5 border-black/10 text-black'
              }`}
            >
              {item}
            </span>
          ))}
        </div>
      </div>

      {/* Direct Contact List */}
      <div className="pt-6 space-y-3">
        <div className="text-[11px] font-mono uppercase tracking-widest text-[#7a7a7a] mb-2">
          Verified Direct Contact
        </div>

        {/* WhatsApp Button */}
        <a
          href={PERSONAL_INFO.contact.whatsapp.url}
          target="_blank"
          rel="noopener noreferrer"
          id="profile-whatsapp-link"
          className={`group flex items-center justify-between p-3 rounded-xl border transition-all ${
            darkMode
              ? 'bg-white/3 border-white/10 hover:border-emerald-500/50 hover:bg-emerald-500/5'
              : 'bg-black/2 border-black/10 hover:border-emerald-600/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] text-[#8a8a8a] uppercase font-mono">WhatsApp</div>
              <div className="text-sm font-medium font-mono text-[#f4efe6]">
                {PERSONAL_INFO.contact.whatsapp.display}
              </div>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-[#8a8a8a] group-hover:text-emerald-400 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </a>

        {/* Instagram Button */}
        <a
          href={PERSONAL_INFO.contact.instagram.url}
          target="_blank"
          rel="noopener noreferrer"
          id="profile-instagram-link"
          className={`group flex items-center justify-between p-3 rounded-xl border transition-all ${
            darkMode
              ? 'bg-white/3 border-white/10 hover:border-[#d4af37]/50 hover:bg-[#d4af37]/5'
              : 'bg-black/2 border-black/10 hover:border-[#9e7d17]/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center">
              <Instagram className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] text-[#8a8a8a] uppercase font-mono">Instagram</div>
              <div className="text-sm font-medium font-mono text-[#f4efe6]">
                {PERSONAL_INFO.contact.instagram.handle}
              </div>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-[#8a8a8a] group-hover:text-[#d4af37] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </a>

        {/* Email Button */}
        <a
          href={PERSONAL_INFO.contact.email.url}
          id="profile-email-link"
          className={`group flex items-center justify-between p-3 rounded-xl border transition-all ${
            darkMode
              ? 'bg-white/3 border-white/10 hover:border-amber-500/50 hover:bg-amber-500/5'
              : 'bg-black/2 border-black/10 hover:border-amber-600/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] text-[#8a8a8a] uppercase font-mono">Email</div>
              <div className="text-sm font-medium font-mono text-[#f4efe6]">
                {PERSONAL_INFO.contact.email.address}
              </div>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-[#8a8a8a] group-hover:text-amber-400 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </a>

        {/* Phone Button */}
        <a
          href={PERSONAL_INFO.contact.phone.url}
          id="profile-phone-link"
          className={`group flex items-center justify-between p-3 rounded-xl border transition-all ${
            darkMode
              ? 'bg-white/3 border-white/10 hover:border-blue-500/50 hover:bg-blue-500/5'
              : 'bg-black/2 border-black/10 hover:border-blue-600/50'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] text-[#8a8a8a] uppercase font-mono">Phone</div>
              <div className="text-sm font-medium font-mono text-[#f4efe6]">
                {PERSONAL_INFO.contact.phone.display}
              </div>
            </div>
          </div>
          <ArrowUpRight className="w-4 h-4 text-[#8a8a8a] group-hover:text-blue-400 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </a>
      </div>
    </div>
  );
};
