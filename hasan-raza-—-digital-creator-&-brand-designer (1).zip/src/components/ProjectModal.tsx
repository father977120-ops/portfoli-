import React, { useEffect } from 'react';
import { X, ArrowLeft, ArrowUpRight, Wrench, CheckCircle2, Globe } from 'lucide-react';
import { Project } from '../types';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
  darkMode: boolean;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose, darkMode }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div
      id="project-detail-modal-overlay"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md p-4 sm:p-6 md:p-10 flex justify-center items-start animate-fadeIn"
      role="dialog"
      aria-modal="true"
    >
      {/* Modal Container */}
      <div
        className={`relative w-full max-w-5xl rounded-3xl border shadow-2xl my-6 overflow-hidden transition-all ${
          darkMode
            ? 'bg-[#0f0f0f] border-white/15 text-[#f4efe6]'
            : 'bg-[#faf6ee] border-black/15 text-[#0c0c0c]'
        }`}
      >
        {/* Top Control Bar */}
        <div className="sticky top-0 z-20 px-6 sm:px-8 py-4 border-b flex items-center justify-between backdrop-blur-xl bg-inherit/90">
          <button
            type="button"
            onClick={onClose}
            id="modal-back-to-work-button"
            className="inline-flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-wider text-[#d4af37] hover:underline"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>← Back to Work</span>
          </button>

          <div className="flex items-center gap-3">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-emerald-500 text-black font-mono font-bold text-xs uppercase tracking-wider hover:bg-emerald-400 transition-all shadow-md"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Visit Live App ↗</span>
              </a>
            )}

            <button
              type="button"
              onClick={onClose}
              id="modal-close-button"
              aria-label="Close Project Detail Modal"
              className="p-2 rounded-full border border-white/10 hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Hero Visual & Header */}
        <div className="relative h-72 sm:h-96 w-full overflow-hidden">
          <img
            src={project.coverImage}
            alt={project.name}
            className="w-full h-full object-cover"
            loading="lazy"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          
          <div className="absolute bottom-6 left-6 right-6 sm:left-10 sm:right-10 text-white flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <div className="flex flex-wrap items-center gap-3 text-xs font-mono mb-2">
                <span className="px-2.5 py-1 rounded bg-[#d4af37] text-black font-bold">
                  {project.year}
                </span>
                <span className="text-[#f4efe6]/80 uppercase tracking-widest">
                  {project.category}
                </span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight uppercase">
                {project.name}
              </h2>
            </div>

            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#d4af37] text-black font-heading font-bold text-xs uppercase tracking-wider hover:bg-[#ebd383] transition-all shadow-lg shrink-0 self-start sm:self-end"
              >
                <Globe className="w-4 h-4" />
                <span>Open Live Website ↗</span>
              </a>
            )}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-10 space-y-12">
          
          {/* Section 1: Overview & Tools */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-8 border-b border-white/10">
            <div className="lg:col-span-2 space-y-3">
              <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37]">
                01 / Project Overview
              </span>
              <p className={`text-base sm:text-lg leading-relaxed ${
                darkMode ? 'text-[#d4cebe]' : 'text-[#333]'
              }`}>
                {project.overview}
              </p>
            </div>

            <div className={`p-5 rounded-2xl border ${
              darkMode ? 'bg-white/3 border-white/10' : 'bg-black/3 border-black/10'
            }`}>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#d4af37] mb-3">
                <Wrench className="w-3.5 h-3.5" />
                <span>Tools Used</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {project.toolsUsed.map((tool) => (
                  <span
                    key={tool}
                    className="text-xs px-2.5 py-1 rounded-md bg-white/5 border border-white/10 font-mono"
                  >
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Section 2: Challenge & Concept */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className={`p-6 rounded-2xl border ${
              darkMode ? 'bg-white/2 border-white/10' : 'bg-black/2 border-black/10'
            }`}>
              <span className="text-xs font-mono uppercase tracking-widest text-red-400 block mb-2">
                02 / The Challenge
              </span>
              <p className="text-sm leading-relaxed text-[#c4beaf]">
                {project.challenge}
              </p>
            </div>

            <div className={`p-6 rounded-2xl border ${
              darkMode ? 'bg-white/2 border-white/10' : 'bg-black/2 border-black/10'
            }`}>
              <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37] block mb-2">
                03 / Creative Concept
              </span>
              <p className="text-sm leading-relaxed text-[#c4beaf]">
                {project.concept}
              </p>
            </div>
          </div>

          {/* Section 3: Design Direction */}
          <div className={`p-6 rounded-2xl border ${
            darkMode ? 'bg-white/2 border-white/10' : 'bg-black/2 border-black/10'
          }`}>
            <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37] block mb-2">
              04 / Design Direction
            </span>
            <p className="text-sm sm:text-base leading-relaxed text-[#c4beaf]">
              {project.designDirection}
            </p>
          </div>

          {/* Section 4: Process Steps */}
          <div className="space-y-4">
            <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37] block">
              05 / Execution Process
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {project.process.map((step, idx) => (
                <div
                  key={idx}
                  className="flex items-start gap-3 p-4 rounded-xl border border-white/10 bg-white/2"
                >
                  <span className="text-xs font-mono font-bold text-[#d4af37] px-2 py-0.5 rounded bg-[#d4af37]/10">
                    0{idx + 1}
                  </span>
                  <p className="text-xs text-[#c4beaf] leading-relaxed">
                    {step}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Section 5: Final Result */}
          <div className="p-6 rounded-2xl bg-[#d4af37]/10 border border-[#d4af37]/30">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#d4af37] mb-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>06 / Final Result</span>
            </div>
            <p className="text-sm sm:text-base font-medium text-[#f4efe6]">
              {project.finalResult}
            </p>
          </div>

          {/* Section 6: Project Gallery */}
          <div className="space-y-6 pt-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37]">
                08 / Project Gallery
              </span>
              <span className="text-[11px] font-mono text-[#8a8a8a]">
                High Fidelity Artifacts
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {project.gallery.map((item, idx) => (
                <div
                  key={idx}
                  className="group rounded-2xl overflow-hidden border border-white/10 bg-black/40 flex flex-col"
                >
                  <div className="h-48 overflow-hidden">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div className="text-xs font-bold text-white mb-1">
                      {item.title}
                    </div>
                    <div className="text-[11px] text-[#8a8a8a] leading-relaxed">
                      {item.caption}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Back Button & Live Link */}
          <div className="pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#d4af37] text-black font-heading font-bold text-xs uppercase tracking-wider hover:bg-[#ebd383] transition-all"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Work</span>
              </button>

              {project.liveUrl && (
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-emerald-500 text-black font-heading font-bold text-xs uppercase tracking-wider hover:bg-emerald-400 transition-all shadow-md"
                >
                  <Globe className="w-4 h-4" />
                  <span>Visit Live App ↗</span>
                </a>
              )}
            </div>

            <a
              href="#contact"
              onClick={() => {
                onClose();
                const el = document.getElementById('contact');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#8a8a8a] hover:text-[#d4af37]"
            >
              <span>Discuss Similar Project</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      </div>
    </div>
  );
};
