import React from 'react';
import { ArrowUpRight, Sparkles, CheckCircle, Palette, Video, Cpu, Layout, FileText, Wand2 } from 'lucide-react';
import { SERVICES } from '../data/portfolioData';

interface ServicesProps {
  darkMode: boolean;
}

export const Services: React.FC<ServicesProps> = ({ darkMode }) => {
  const getIcon = (id: string) => {
    switch (id) {
      case 'brand-design': return <Palette className="w-5 h-5" />;
      case 'graphic-design': return <FileText className="w-5 h-5" />;
      case 'video-editing': return <Video className="w-5 h-5" />;
      case 'ai-prompt-engineering': return <Cpu className="w-5 h-5" />;
      case 'ui-ux-design': return <Layout className="w-5 h-5" />;
      case 'digital-content': return <CheckCircle className="w-5 h-5" />;
      case 'ai-visual-creation': return <Wand2 className="w-5 h-5" />;
      default: return <Sparkles className="w-5 h-5" />;
    }
  };

  const scrollToAiVisuals = (e: React.MouseEvent) => {
    e.preventDefault();
    const el = document.getElementById('ai-visuals');
    if (el) {
      const topOffset = 80;
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - topOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section
      id="services"
      className={`py-24 border-b transition-colors ${
        darkMode ? 'border-white/10 bg-[#0f0f0f]' : 'border-black/10 bg-[#ebe5da]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
                02 / SERVICES
              </span>
              <div className="h-[1px] w-12 bg-[#d4af37]/40" />
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight uppercase leading-[1.08]">
              WHAT I CAN<br />
              <span className="text-[#d4af37]">CREATE FOR YOU.</span>
            </h2>
          </div>

          <p className={`max-w-md text-sm sm:text-base ${
            darkMode ? 'text-[#a8a8a8]' : 'text-[#555]'
          }`}>
            Comprehensive creative solutions combining visual craftsmanship, cinematic video editing, and modern AI automation workflows.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((service) => {
            const isSpecial = service.isAiSpecialty;
            return (
              <div
                key={service.id}
                className={`group relative rounded-3xl p-7 border transition-all duration-300 flex flex-col justify-between ${
                  isSpecial
                    ? darkMode
                      ? 'bg-gradient-to-b from-[#1c170d] to-[#12100a] border-[#d4af37]/40 hover:border-[#d4af37] shadow-lg shadow-[#d4af37]/5 md:col-span-2 lg:col-span-3'
                      : 'bg-gradient-to-b from-[#fffaf0] to-[#f5ebd8] border-[#9e7d17]/40 hover:border-[#9e7d17] md:col-span-2 lg:col-span-3'
                    : darkMode
                    ? 'bg-gradient-to-b from-[#141414] to-[#0d0d0d] border-white/10 hover:border-white/25 hover:bg-white/5'
                    : 'bg-[#faf6ee] border-black/10 hover:border-black/25'
                }`}
              >
                <div>
                  {/* Top metadata row */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        isSpecial
                          ? 'bg-[#d4af37] text-black'
                          : 'bg-white/5 border border-white/10 text-[#d4af37]'
                      }`}>
                        {getIcon(service.id)}
                      </div>
                      <span className="font-mono text-xs font-bold tracking-widest text-[#8a8a8a]">
                        {service.number}
                      </span>
                    </div>

                    {isSpecial && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-mono font-semibold tracking-wider bg-[#d4af37]/20 border border-[#d4af37]/40 text-[#f4efe6]">
                        <Sparkles className="w-3 h-3 text-[#d4af37]" />
                        FEATURED SERVICE
                      </span>
                    )}
                  </div>

                  {/* Title & Description */}
                  <h3 className="font-heading text-xl sm:text-2xl font-bold tracking-tight mb-3 uppercase">
                    {service.title}
                  </h3>
                  <p className={`text-sm mb-6 leading-relaxed ${
                    darkMode ? 'text-[#a8a8a8]' : 'text-[#444]'
                  }`}>
                    {service.description}
                  </p>

                  {/* Included deliverables */}
                  <div className="pt-2 pb-6 border-t border-white/10">
                    <div className="text-[11px] font-mono uppercase tracking-wider text-[#7a7a7a] mb-3">
                      Deliverables &amp; Formats
                    </div>
                    <ul className={`grid gap-2 text-xs font-medium ${
                      isSpecial ? 'grid-cols-2 sm:grid-cols-3' : 'grid-cols-2'
                    }`}>
                      {service.items.map((item) => (
                        <li key={item} className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Card Action Link */}
                <div className="pt-2">
                  {isSpecial ? (
                    <button
                      type="button"
                      onClick={scrollToAiVisuals}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#d4af37] text-black font-heading font-bold text-xs uppercase tracking-wider hover:bg-[#edd17b] transition-all"
                    >
                      <span>Explore AI Work</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <a
                      href="#contact"
                      className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-[#8a8a8a] group-hover:text-[#d4af37] transition-colors"
                    >
                      <span>Request Service</span>
                      <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
