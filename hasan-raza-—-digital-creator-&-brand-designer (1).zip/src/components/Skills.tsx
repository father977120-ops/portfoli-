import React from 'react';
import { Palette, Video, Cpu, Code2, Wrench, Check } from 'lucide-react';
import { SKILL_CATEGORIES, REAL_TOOLS } from '../data/portfolioData';

interface SkillsProps {
  darkMode: boolean;
}

export const Skills: React.FC<SkillsProps> = ({ darkMode }) => {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'DESIGN': return <Palette className="w-5 h-5 text-[#d4af37]" />;
      case 'VIDEO': return <Video className="w-5 h-5 text-emerald-400" />;
      case 'AI': return <Cpu className="w-5 h-5 text-purple-400" />;
      case 'DEVELOPMENT': return <Code2 className="w-5 h-5 text-blue-400" />;
      default: return <Wrench className="w-5 h-5 text-[#d4af37]" />;
    }
  };

  return (
    <section
      id="skills"
      className={`py-24 border-b transition-colors ${
        darkMode ? 'border-white/10 bg-[#0c0c0c]' : 'border-black/10 bg-[#f4efe6]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
                04 / SKILLS
              </span>
              <div className="h-[1px] w-12 bg-[#d4af37]/40" />
            </div>
            
            <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight uppercase leading-[1.08]">
              TOOLS ARE USEFUL.<br />
              <span className="text-[#d4af37]">THINKING MATTERS MORE.</span>
            </h2>
          </div>

          <p className={`max-w-md text-sm sm:text-base ${
            darkMode ? 'text-[#a8a8a8]' : 'text-[#555]'
          }`}>
            Software and AI models evolve constantly. Enduring creative instincts, strategic visual storytelling, and taste remain constant.
          </p>
        </div>

        {/* 4 Primary Capability Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {SKILL_CATEGORIES.map((cat) => (
            <div
              key={cat.category}
              className={`rounded-3xl p-6 border transition-all duration-300 flex flex-col justify-between ${
                darkMode
                  ? 'bg-gradient-to-b from-[#141414] to-[#0a0a0a] border-white/10 hover:border-white/20'
                  : 'bg-[#faf6ee] border-black/10 hover:border-black/20'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="p-2.5 rounded-2xl bg-white/5 border border-white/10">
                    {getCategoryIcon(cat.category)}
                  </div>
                  <span className="text-[11px] font-mono text-[#8a8a8a] tracking-widest">
                    {cat.skills.length} SKILLS
                  </span>
                </div>

                <h3 className="font-heading text-xl font-bold tracking-tight mb-4 uppercase">
                  {cat.category}
                </h3>

                <ul className="space-y-2.5">
                  {cat.skills.map((skill) => (
                    <li key={skill} className="flex items-center gap-2.5 text-xs font-medium">
                      <Check className="w-3.5 h-3.5 text-[#d4af37] shrink-0" />
                      <span className={darkMode ? 'text-[#d8d2c6]' : 'text-[#333]'}>
                        {skill}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-6 pt-4 border-t border-white/10 text-[10px] font-mono uppercase tracking-wider text-[#7a7a7a]">
                Core Competency
              </div>
            </div>
          ))}
        </div>

        {/* Real Tools Badges Area */}
        <div
          id="real-tools-badge-container"
          className={`rounded-3xl p-8 border ${
            darkMode
              ? 'bg-gradient-to-b from-[#141414] to-[#0e0e0e] border-white/10'
              : 'bg-[#faf6ee] border-black/10'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37] block mb-1">
                Verified Toolchain
              </span>
              <h4 className="text-xl font-bold tracking-tight uppercase">
                Software &amp; Platforms Actually Used
              </h4>
            </div>
            <span className="text-xs font-mono text-[#8a8a8a]">
              Zero Inflated Claims • 100% Real Workflow
            </span>
          </div>

          <div className="flex flex-wrap gap-3">
            {REAL_TOOLS.map((tool) => (
              <div
                key={tool.name}
                className={`flex items-center gap-3 px-5 py-3 rounded-2xl border transition-all ${
                  darkMode
                    ? 'bg-white/3 border-white/10 hover:border-[#d4af37]/50 hover:bg-white/5'
                    : 'bg-black/2 border-black/10 hover:border-[#9e7d17]/50'
                }`}
              >
                <div className="w-2 h-2 rounded-full bg-[#d4af37]" />
                <div>
                  <div className="text-sm font-bold font-heading uppercase text-[#f4efe6]">
                    {tool.name}
                  </div>
                  <div className="text-[10px] font-mono text-[#8a8a8a] uppercase">
                    {tool.category}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
