import React from 'react';
import { MessageSquareQuote, ShieldCheck } from 'lucide-react';

interface TestimonialsProps {
  darkMode: boolean;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ darkMode }) => {
  return (
    <section
      id="testimonials"
      className={`py-20 border-b transition-colors ${
        darkMode ? 'border-white/10 bg-[#090909]' : 'border-black/10 bg-[#f0eae0]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase">
            ENDORSEMENTS
          </span>
          <div className="h-[1px] w-12 bg-[#d4af37]/40" />
        </div>

        <div
          id="testimonials-placeholder-card"
          className={`rounded-3xl p-8 sm:p-12 border transition-all ${
            darkMode
              ? 'bg-gradient-to-b from-[#121212] to-[#0a0a0a] border-white/10'
              : 'bg-[#faf6ee] border-black/10'
          }`}
        >
          <div className="max-w-2xl space-y-4">
            <div className="flex items-center gap-3 text-xs font-mono text-[#8a8a8a] uppercase">
              <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
              <span>Authenticity First • Zero Fabricated Reviews</span>
            </div>

            <div className="flex items-start gap-4 pt-2">
              <div className="p-3 rounded-2xl bg-[#d4af37]/10 text-[#d4af37] border border-[#d4af37]/20 shrink-0">
                <MessageSquareQuote className="w-6 h-6" />
              </div>

              <div>
                <h3 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight text-[#f4efe6]">
                  CLIENT FEEDBACK COMING SOON
                </h3>
                <p className={`text-sm sm:text-base leading-relaxed mt-2 ${
                  darkMode ? 'text-[#a8a8a8]' : 'text-[#555]'
                }`}>
                  Currently partnering with selective creators, brands, and digital initiatives. Real client evaluations, testimonials, and verified collaborative impact will be featured here upon project completion.
                </p>
                <div className="mt-4 inline-flex items-center gap-2 text-xs font-mono text-[#d4af37]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-pulse" />
                  <span>Accepting new commission inquiries for 2026</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
