import React from 'react';
import { Sparkles, Eye, Layers, Compass } from 'lucide-react';
import { WHY_WORK_WITH_ME } from '../data/portfolioData';

interface WhyMeProps {
  darkMode: boolean;
}

export const WhyMe: React.FC<WhyMeProps> = ({ darkMode }) => {
  const getFeatureIcon = (id: string) => {
    switch (id) {
      case 'human-ai': return <Sparkles className="w-5 h-5 text-[#d4af37]" />;
      case 'detail-focused': return <Eye className="w-5 h-5 text-emerald-400" />;
      case 'multi-skilled': return <Layers className="w-5 h-5 text-purple-400" />;
      case 'always-learning': return <Compass className="w-5 h-5 text-blue-400" />;
      default: return <Sparkles className="w-5 h-5 text-[#d4af37]" />;
    }
  };

  return (
    <section
      id="why-me"
      className={`py-24 border-b transition-colors ${
        darkMode ? 'border-white/10 bg-[#0c0c0c]' : 'border-black/10 bg-[#f4efe6]'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <span className="text-xs font-mono font-bold tracking-widest text-[#d4af37] uppercase block mb-3">
            05 / VALUE PROPOSITION
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight uppercase leading-[1.08]">
            CREATIVE THINKING.<br />
            <span className="text-[#d4af37]">DIGITAL EXECUTION.</span>
          </h2>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHY_WORK_WITH_ME.map((item) => (
            <div
              key={item.id}
              className={`rounded-3xl p-7 border transition-all duration-300 flex flex-col justify-between ${
                darkMode
                  ? 'bg-gradient-to-b from-[#141414] to-[#0a0a0a] border-white/10 hover:border-white/20'
                  : 'bg-[#faf6ee] border-black/10 hover:border-black/20'
              }`}
            >
              <div>
                <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mb-6">
                  {getFeatureIcon(item.id)}
                </div>

                <h3 className="font-heading text-xl font-bold tracking-tight mb-2 uppercase">
                  {item.title}
                </h3>

                <p className="text-xs font-mono text-[#d4af37] mb-3">
                  {item.summary}
                </p>

                <p className={`text-xs sm:text-sm leading-relaxed ${
                  darkMode ? 'text-[#a8a8a8]' : 'text-[#555]'
                }`}>
                  {item.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-white/10 text-[10px] font-mono uppercase text-[#7a7a7a]">
                Standard Practice
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
