import { Project, AiVisualItem, ServiceItem, SkillCategory, ProcessStep } from '../types';

export const PERSONAL_INFO = {
  name: "HASAN RAZA",
  primaryTitle: "Digital Creator & Brand Designer",
  roles: [
    "Digital Creator",
    "Brand Designer",
    "AI Visual Creator",
    "Prompt Engineer",
    "AI Automation Creator",
    "Video Editor",
    "UI/UX Designer"
  ],
  specialties: [
    "Brand Design",
    "AI Visuals",
    "Video Editing",
    "Prompt Engineering",
    "AI Automation"
  ],
  allSpecialties: [
    "Brand Design",
    "Graphic Design",
    "Video Editing",
    "AI Automation",
    "Prompt Engineering",
    "UI/UX",
    "Digital Content"
  ],
  positioning: "I turn ideas into brands, visuals and digital experiences.",
  supportingLine: "Designing brands. Creating content. Building with AI.",
  finalMessage: "I combine creativity, design and AI to turn ideas into powerful visual experiences.",
  aboutHero: "I’m Hasan Raza — a digital creator focused on brand design, visual content, AI-powered workflows and modern digital experiences.",
  availability: "Available for selected projects",
  contact: {
    instagram: {
      handle: "@hasanrazau9",
      url: "https://instagram.com/hasanrazau9"
    },
    email: {
      address: "hasanrazau9@gmail.com",
      url: "mailto:hasanrazau9@gmail.com"
    },
    phone: {
      display: "+91 9631378862",
      url: "tel:+919631378862"
    },
    whatsapp: {
      display: "+91 9631378862",
      url: "https://wa.me/919631378862"
    }
  }
};

export const SERVICES: ServiceItem[] = [
  {
    id: "brand-design",
    number: "01",
    title: "BRAND DESIGN",
    description: "Create memorable visual identities that communicate the personality of a business.",
    items: [
      "Logo Design",
      "Brand Identity",
      "Brand Guidelines",
      "Business Cards",
      "Social Media Branding",
      "Packaging"
    ]
  },
  {
    id: "graphic-design",
    number: "02",
    title: "GRAPHIC DESIGN",
    description: "Creative visuals designed for real-world communication.",
    items: [
      "Posters",
      "Social Media Posts",
      "Flyers",
      "Menus",
      "Banners",
      "Marketing Creatives"
    ]
  },
  {
    id: "video-editing",
    number: "03",
    title: "VIDEO EDITING",
    description: "Transform raw footage into engaging visual stories.",
    items: [
      "Reels",
      "Promotional Videos",
      "Event Videos",
      "Wedding Videos",
      "Product Videos",
      "Social Media Content"
    ]
  },
  {
    id: "ai-prompt-engineering",
    number: "04",
    title: "AI & PROMPT ENGINEERING",
    description: "Use AI strategically to improve creative and business workflows.",
    items: [
      "Prompt Engineering",
      "AI Content Workflows",
      "AI-assisted Design",
      "AI Automation",
      "Creative AI Solutions"
    ]
  },
  {
    id: "ui-ux-design",
    number: "05",
    title: "UI/UX & WEB DESIGN",
    description: "Design modern digital interfaces that are simple and engaging.",
    items: [
      "Landing Pages",
      "Portfolio Websites",
      "Business Websites",
      "Dashboard UI",
      "Mobile UI Concepts",
      "Responsive Design"
    ]
  },
  {
    id: "digital-content",
    number: "06",
    title: "DIGITAL CONTENT",
    description: "Create content systems that help brands communicate consistently.",
    items: [
      "Social Media Creatives",
      "Content Concepts",
      "Campaign Visuals",
      "Digital Branding",
      "Promotional Content"
    ]
  },
  {
    id: "ai-visual-creation",
    number: "07",
    title: "AI VISUAL CREATION",
    description: "Creating unique AI-powered visuals for brands, social media, campaigns and creative concepts.",
    items: [
      "AI Portraits",
      "AI Product Images",
      "AI Advertising Creatives",
      "AI Concept Art",
      "Social Media Visuals",
      "Creative AI Experiments"
    ],
    isAiSpecialty: true
  }
];

export const PROJECTS: Project[] = [
  {
    id: "ai-studio-app",
    name: "AI WEB EXPERIENCE",
    category: "AI Web Application • Prompt Engineering • UI/UX",
    shortDescription: "An interactive, AI-powered web application and intelligent interface built and deployed on Google AI Studio.",
    year: "2025",
    coverImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
    liveUrl: "https://sdffsdfsdsg.ai.studio/",
    overview: "An advanced web experience and digital application built with Google AI Studio, combining smart generative workflows, intuitive interaction design, and modern frontend aesthetics.",
    challenge: "Translating complex generative AI capabilities into an elegant, user-friendly, and accessible web interface that responds intuitively with minimum cognitive load.",
    concept: "Merging fluid generative AI workflows with a sleek, minimalist cyber-editorial design system featuring rapid responsiveness and purposeful visual feedback.",
    designDirection: "Deep obsidian canvas paired with luminous golden and amber accents, crisp typographic hierarchy, and clean modular component cards.",
    process: [
      "Prompt Architecture & Logic: Designing robust prompt matrices and backend workflows for intelligent processing.",
      "Interface Wireframing: Creating high-contrast, responsive UI layouts tailored for smooth interactive sessions.",
      "Frontend & AI Studio Deployment: Configuring application parameters and publishing live to Google AI Studio.",
      "Usability Testing: Refining user interactions, latency handling, and visual micro-feedback."
    ],
    finalResult: "A live, deployed AI application active at sdffsdfsdsg.ai.studio showcasing practical AI automation and modern interface craft.",
    toolsUsed: ["Google AI Studio", "Prompt Engineering", "UI/UX", "Figma"],
    gallery: [
      {
        title: "Intelligent Interface & Canvas",
        caption: "Minimalist workspace layout structured for seamless human-AI interaction.",
        image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Adaptive Prompt Execution Pipeline",
        caption: "Engineered prompt architectures delivering consistent, high-fidelity generative outcomes.",
        image: "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Responsive Application View",
        caption: "Cross-device responsive design guaranteeing clean interaction across mobile and desktop.",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "outreach-management",
    name: "OUTREACH MANAGEMENT",
    category: "Web Design • System UI • School Outreach",
    shortDescription: "A comprehensive digital management web application designed for organizing school outreach programmes and community initiatives.",
    year: "2025",
    coverImage: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80",
    liveUrl: "https://outreachmanagement.vercel.app/",
    overview: "Designed and engineered a dedicated web application for managing school outreach programmes. The platform streamlines student and volunteer coordination, community partner tracking, initiative schedules, event registration, and impact reporting for academic institutions.",
    challenge: "School outreach programs often suffer from fragmented communication between coordinators, students, and community partners across disjointed spreadsheets. The challenge was building an intuitive, accessible dashboard that unifies event operations while keeping data entry rapid and clutter-free.",
    concept: "A clean, human-centered institutional portal balancing administrative rigor with welcoming community energy. Built with structured cards, status trackers, calendar views, and actionable telemetry.",
    designDirection: "Modern academic aesthetic featuring crisp typography, reassuring deep blues and warm accents, responsive card grids, and high-readability data tables tailored for fast desktop and tablet use.",
    process: [
      "User Journey Mapping: Interviewing school coordinators to map out volunteer signups, venue tracking, and event check-ins.",
      "Information Architecture: Structuring outreach modules including campaigns, attendee rosters, and impact metrics.",
      "Design System & UI Components: Crafting responsive forms, quick status tags, and scheduling views.",
      "Deployment & Optimization: Hosted on Vercel with lightning-fast load times and accessible mobile layouts."
    ],
    finalResult: "A live, production-deployed web application active at outreachmanagement.vercel.app empowering school administrators to orchestrate community outreach smoothly.",
    toolsUsed: ["Figma", "Web Design", "Canva", "UI/UX"],
    gallery: [
      {
        title: "Programme Coordinator Dashboard",
        caption: "Centralized interface tracking active campaigns, volunteer quotas, and event schedules.",
        image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Community Partner & School Outreach",
        caption: "Structured directories for academic institutions and partner community organizations.",
        image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Impact Telemetry & Volunteer Metrics",
        caption: "Data-informed summaries measuring student participation hours and outreach deliverables.",
        image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "shaadmaan",
    name: "SHAADMAAN",
    category: "Web Design • Brand Presence • UI/UX",
    shortDescription: "An elegant, bespoke web presence and digital experience crafted with immersive visuals and modern interactivity.",
    year: "2025",
    coverImage: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80",
    liveUrl: "https://shaadmaan.vercel.app/",
    overview: "Shaadmaan is a custom-designed digital web presence built to deliver a distinguished, memorable online experience. The website balances atmospheric visual storytelling with clean, high-performance web architecture deployed on Vercel.",
    challenge: "Crafting a distinctive aesthetic that feels bespoke and premium without sacrificing mobile fluidity, fast rendering, or content discoverability.",
    concept: "Merging contemporary minimalist layouts with rich typography, generous breathing room, and seamless micro-interactions that elevate brand credibility.",
    designDirection: "Understated elegance featuring high-contrast typography, deep neutral tones, smooth transitions, and a mobile-first responsive layout.",
    process: [
      "Brand Alignment & Art Direction: Defining visual moodboards, typographic hierarchy, and tonal palette.",
      "Wireframing & Prototyping: Constructing responsive screen layouts from mobile viewports to ultra-wide displays.",
      "Interactive Development: Implementing smooth transitions, responsive grids, and clean component architecture.",
      "Vercel Deployment: Live release with custom domain configuration and performance optimization."
    ],
    finalResult: "A live web application active at shaadmaan.vercel.app showcasing polished brand aesthetics and responsive web craft.",
    toolsUsed: ["Figma", "Web Design", "Photoshop", "UI/UX"],
    gallery: [
      {
        title: "Hero Architecture & Display Typography",
        caption: "Atmospheric introductory experience setting the tone with bold layout geometry.",
        image: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Editorial Content Hierarchy",
        caption: "Structured layout with generous white space and clean typography.",
        image: "https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Responsive Mobile Experience",
        caption: "Optimized touch navigation and streamlined mobile reading flow.",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "vaedits",
    name: "VAEDITS",
    category: "Video Editing • Photography • Graphic Design",
    shortDescription: "A creative visual identity and digital presence for a modern media and editing brand.",
    year: "2025",
    coverImage: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80",
    overview: "VAEDITS is a media production and post-processing personal brand identity designed to reflect high-precision pacing, cinematic aesthetics, and clean digital storytelling. The project required creating an authentic identity system adaptable for video intros, social watermarks, thumbnail templates, and creative portfolio presentations.",
    challenge: "Developing a brand aesthetic that conveys cinematic mastery and modern video craft without feeling cluttered or generic, while remaining visually sharp across micro-resolutions like profile avatars and watermark overlays.",
    concept: "The visual language combines high-contrast dark frames, anamorphic proportions, clean geometric typography, and glowing focal points mimicking camera viewfinders and timeline playheads.",
    designDirection: "Minimalist black-and-silver editorial styling with dynamic framing. Subtle grid overlays and lens-meter markings provide subtle technical credibility.",
    process: [
      "Brand Discovery: Analyzing competitor visual tones in the creator video editing ecosystem.",
      "Symbol & Mark Drafting: Developing minimalist lens-and-waveform glyph geometry.",
      "Digital Typography System: Pairing geometric bold display type with clean condensed labels.",
      "Brand Collateral: Watermarks, YouTube / Instagram aspect ratio assets, and media kit deck."
    ],
    finalResult: "A comprehensive brand identity kit that gives VAEDITS a recognizable, premium presence across Instagram reels, YouTube deliverables, and client media reviews.",
    toolsUsed: ["Photoshop", "Canva", "Adobe Tools", "Figma"],
    gallery: [
      {
        title: "Brand Mark & Grid Geometry",
        caption: "Precision geometric symbol designed for high-resolution video watermarks.",
        image: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Cinematic Color Palette & Contrast",
        caption: "Deep obsidian, slate grays, and luminous white for editing room environments.",
        image: "https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Social Video Deliverables Kit",
        caption: "Vertical reel frames, lower-third overlays, and title card treatments.",
        image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "printia",
    name: "PRINTIA",
    category: "Branding • Printing • Business Design",
    shortDescription: "A complete visual identity concept for a modern printing and customization business.",
    year: "2025",
    coverImage: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1200&q=80",
    overview: "PRINTIA reimagines the traditional commercial printing shop into an upscale, design-forward customization brand. The concept bridges the tactile quality of physical paper stock and ink with the frictionless simplicity of digital ordering.",
    challenge: "Overcoming the cluttered, outdated perception of neighborhood print shops by establishing a crisp, modern, trustworthy aesthetic centered on craft, precision colors, and packaging finesse.",
    concept: "Inspired by CMYK color registration marks and architectural paper trimming grids. The identity celebrates the physical transition from digital pixel to tangible print craft.",
    designDirection: "Warm cream surfaces paired with deep charcoal type and subtle color registration points, conveying bespoke craftsmanship and industrial reliability.",
    process: [
      "Auditing print-on-demand and specialty print studio brands across international markets.",
      "Developing modular registration crosshairs and typographic grid standards.",
      "Designing physical stationery collateral: textured business cards, envelopes, and packaging tape.",
      "Digital shopfront concept: clean ordering UI for customized corporate merchandise."
    ],
    finalResult: "A fully realized visual identity concept spanning physical print collateral, packaging labels, delivery boxes, and digital store banners.",
    toolsUsed: ["Figma", "Photoshop", "Canva", "Adobe Tools"],
    gallery: [
      {
        title: "Stationery Suite & Packaging",
        caption: "Tactile mockups demonstrating heavy-stock business cards and custom wax-seal envelopes.",
        image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Print Registration Mark Details",
        caption: "Subtle micro-typography and alignment guides embedded in brand documentation.",
        image: "https://images.unsplash.com/photo-1586075010923-2dd4570fb338?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Packaging & Delivery Experience",
        caption: "Custom packing tape, thank-you cards, and branded unboxing elements.",
        image: "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "pp-paani-puri",
    name: "PP PAANI PURI",
    category: "Brand Identity • Food Business • Digital Experience",
    shortDescription: "A bold food-brand concept combining traditional street food with modern branding and digital experiences.",
    year: "2025",
    coverImage: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1200&q=80",
    overview: "PP PAANI PURI takes one of South Asia's most beloved street delicacies and builds an energetic, appetizing, and hygienic modern brand around it. The identity aims to make street food feel vibrant, fresh, and ready for contemporary quick-service retail kiosks.",
    challenge: "Balancing authentic street food heritage and spontaneous joy with strict modern hygiene cues, clarity of flavor profiles (spicy, tangy, sweet), and social media photogenicity.",
    concept: "A vibrant visual identity utilizing rounded organic shapes reminiscent of the crispy puris, fresh mint leaves, and effervescent spiced water, balanced by contemporary typography.",
    designDirection: "Rich spice-inspired palette (mint green, saffron gold, and deep charcoal) combined with clean geometric signage and appetizing icon illustrations.",
    process: [
      "Culinary Concept Mapping: Identifying key flavor notes and customer sensory touchpoints.",
      "Logo & Emblem Construction: Creating a playful, memorable typographic mark.",
      "Kiosk & Packaging Concepts: Designing eco-friendly take-away bowls, flavor dispensers, and menu boards.",
      "Digital Menu & QR ordering flow: Simple mobile web interface for customized spice levels."
    ],
    finalResult: "A vibrant, scalable brand concept ready for kiosk franchises, food festival pop-ups, and modern delivery packaging.",
    toolsUsed: ["Photoshop", "Figma", "Canva", "Adobe Tools"],
    gallery: [
      {
        title: "Brand Emblem & Menu System",
        caption: "Playful yet structured menu board categorizing spice levels and water varieties.",
        image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Eco Packaging & Takeaway Bowls",
        caption: "Biodegradable 6-cup carrier boxes designed for clean street dining.",
        image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Social Media Campaign Visuals",
        caption: "High-contrast food typography and punchy flavor slogans for Instagram reels.",
        image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "raza-general-store",
    name: "RAZA GENERAL STORE",
    category: "Business • Digital Product • UI",
    shortDescription: "A digital customer-record management concept designed for a local family business.",
    year: "2025",
    coverImage: "https://images.unsplash.com/photo-1556742049-0a67e5572293?auto=format&fit=crop&w=1200&q=80",
    overview: "Raza General Store is a digital bookkeeping and customer credit ledger concept designed specifically to replace cumbersome paper registers ('khata') in local retail environments with an intuitive, mobile-first interface.",
    challenge: "Local shop owners need ultra-fast input speeds while attending to walk-in customers. The UI had to be readable in bright daylight, support single-thumb navigation, and avoid confusing accounting terminology.",
    concept: "A digital card-based ledger that presents customer balances, pending credit tallies, and WhatsApp reminder shortcuts with zero friction.",
    designDirection: "High-contrast clean layout with large touch targets, color-coded credit/debit badges (green for received, amber for owed), and bold numerical readability.",
    process: [
      "User Observation: Studying daily register entries in real retail counters during peak hours.",
      "Information Architecture: Streamlining transaction entry to under 3 screen taps.",
      "Component Design: Creating quick-amount chips (+10, +50, +100, +500) and instant contact search.",
      "Testing: Validating readability across budget smartphone screens under direct store lighting."
    ],
    finalResult: "A lightweight, rapid digital ledger prototype that makes local inventory and balance tracking effortless and transparent.",
    toolsUsed: ["Figma", "Google AI Studio", "ChatGPT", "HTML/CSS"],
    gallery: [
      {
        title: "Customer Balance Dashboard",
        caption: "Overview screen showing total outstanding credit, daily collections, and quick ledger filters.",
        image: "https://images.unsplash.com/photo-1556742049-0a67e5572293?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Rapid Entry Modal Interface",
        caption: "One-handed keypad with preset quantity shortcuts and voice-note attachment.",
        image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "WhatsApp Payment Slip Generator",
        caption: "Formatted receipt generation ready for 1-tap WhatsApp sharing with customers.",
        image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "nemi",
    name: "NEMI",
    category: "Web Design • Programme Management • UI/UX",
    shortDescription: "A modern digital programme management platform concept with public and administrative experiences.",
    year: "2026",
    coverImage: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80",
    overview: "NEMI is a comprehensive digital programme management platform concept designed to bridge public initiative transparency with structured administrative project coordination. It features an open public explorer for civic/programme updates and a focused administrative console.",
    challenge: "Complex initiatives often drown participants in fragmented spreadsheets and inaccessible PDFs. The goal was to unify project timelines, milestones, budget indicators, and application workflows into an editorial, human-friendly web experience.",
    concept: "A dual-layer interface: an inspiring, editorial public portal that tells the programme's human impact story, paired with a dense, highly efficient workspace for program directors.",
    designDirection: "Monochrome minimalism with sharp typography, generous negative space, refined status pills, and interactive gantt/timeline components.",
    process: [
      "Stakeholder Journey Mapping: Mapping public citizen curiosity vs. administrator oversight needs.",
      "Design System Creation: Establishing a tokenized library of cards, metric blocks, and status badges.",
      "Responsive Layout Prototyping: Ensuring rich data tables scale seamlessly to mobile touchscreens.",
      "Interactive Wireframing: Public initiative directory, application submission portal, and milestone tracker."
    ],
    finalResult: "A cohesive, executive-grade web platform prototype combining transparent public storytelling with rigorous operational control.",
    toolsUsed: ["Figma", "Photoshop", "Google AI Studio", "HTML/CSS/JS"],
    gallery: [
      {
        title: "Public Programme Portal",
        caption: "Editorial landing experience showcasing active initiatives, key milestones, and impact metrics.",
        image: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Administrative Milestone Tracker",
        caption: "Real-time project timeline with deliverable checklist and task ownership matrices.",
        image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Public Application & Ingestion Flow",
        caption: "Step-by-step applicant onboarding experience with instant verification feedback.",
        image: "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  },
  {
    id: "ai-automation-prompt-experiments",
    name: "AI AUTOMATION & PROMPT EXPERIMENTS",
    category: "AI • Prompt Engineering • Automation",
    shortDescription: "Creative experiments exploring AI-assisted creativity, prompt engineering and automation workflows.",
    year: "2026",
    coverImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80",
    overview: "A continuous series of hands-on creative experiments investigating how structured prompt engineering, multimodal models, and automated logic chains can amplify brand identity creation, concept art ideation, and rapid content generation.",
    challenge: "AI models often yield generic, repetitive, or unpredictable outputs unless guided by rigorous compositional framing, stylistic constraints, and semantic negative parameters.",
    concept: "Synthesizing classical art direction principles (lighting ratios, focal lengths, camera sensors, architectural movements) into repeatable prompt templates and automated execution workflows.",
    designDirection: "Futuristic creative-tech aesthetics: dark obsidian backdrops, glowing cybernetic nodes, iridescent fluid simulations, and monospace terminal annotations.",
    process: [
      "Prompt Architecture Development: Building structured syntax models for consistent character & product lighting.",
      "Workflow Automation: Testing automated pipelines connecting prompt inputs to image outputs and content copy.",
      "Art Direction Taxonomy: Cataloging camera angles, shutter speeds, film stocks, and atmospheric lighting styles.",
      "Iterative Benchmarking: Refining prompt matrices to achieve reliable commercial aesthetic quality."
    ],
    finalResult: "A proprietary library of prompt frameworks and automated creative workflows that accelerate visual concepting by up to 5x while preserving artisanal brand uniqueness.",
    toolsUsed: ["Google AI Studio", "ChatGPT", "Photoshop", "Canva"],
    gallery: [
      {
        title: "Cinematic Lighting Matrix",
        caption: "Structured prompt experimentation testing volumetric fog, rim lights, and golden-hour shadows.",
        image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Surreal Product Visualization",
        caption: "AI concept generation combining organic botany with precision industrial glass packaging.",
        image: "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=1000&q=80"
      },
      {
        title: "Creative Automation Workflow Architecture",
        caption: "System diagrams mapping prompt inputs, model parameters, and asset post-processing.",
        image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80"
      }
    ]
  }
];

export const AI_VISUALS: AiVisualItem[] = [
  {
    id: "ai-1",
    title: "Cybernetic Obsidian Portrait",
    category: "AI PORTRAITS",
    aspectRatio: "tall",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Studio portraiture with cinematic dual-tone rim light, sculptural shadows, high editorial fidelity."
  },
  {
    id: "ai-2",
    title: "Ethereal Luminescent Glass Product",
    category: "AI PRODUCTS",
    aspectRatio: "square",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Minimalist perfume flask resting on wet obsidian stone, caustic light refractions, macro clarity."
  },
  {
    id: "ai-3",
    title: "Metaphysical Geometry & Architecture",
    category: "AI ART",
    aspectRatio: "tall",
    image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Brutalist curved concrete archways meeting tranquil desert sands under soft twilight sky."
  },
  {
    id: "ai-4",
    title: "Hyper-Modern Campaign Editorial",
    category: "AI ADS",
    aspectRatio: "wide",
    image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "High fashion avant-garde styling, kinetic fabric flow, dramatic high-key contrast."
  },
  {
    id: "ai-5",
    title: "Neural Synapse Dimension",
    category: "AI CONCEPTS",
    aspectRatio: "tall",
    image: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Abstract data flow streams, golden fiber-optic strands interacting in cosmic space."
  },
  {
    id: "ai-6",
    title: "Neo-Kinetic Kinetic Sculpture",
    category: "AI ART",
    aspectRatio: "square",
    image: "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Liquid chrome fluid simulations frozen in mid-air with warm iridescent studio reflections."
  },
  {
    id: "ai-7",
    title: "Artisanal Botanical Skincare",
    category: "AI PRODUCTS",
    aspectRatio: "tall",
    image: "https://images.unsplash.com/photo-1608248597359-bb4bba46c243?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Matte amber glass bottle surrounded by dewy wild ferns, warm natural daylight morning mist."
  },
  {
    id: "ai-8",
    title: "Futuristic Spatial Audio Concept",
    category: "AI ADS",
    aspectRatio: "square",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Suspended matte black headphone hardware with magnetic audio frequency ripples."
  },
  {
    id: "ai-9",
    title: "Neon Cybernetic Gaze",
    category: "AI PORTRAITS",
    aspectRatio: "wide",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Close-up emotive portrait with geometric light projections, micro-contrast, editorial realism."
  },
  {
    id: "ai-10",
    title: "Autonomous City Nexus",
    category: "AI CONCEPTS",
    aspectRatio: "tall",
    image: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=900&q=80",
    instagramUrl: "https://instagram.com/hasanrazau9",
    promptConcept: "Futuristic architectural megastructure with elevated transit lines under nocturnal fog."
  }
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    category: "DESIGN",
    skills: ["Branding", "Graphic Design", "Typography", "Visual Identity", "UI Design"]
  },
  {
    category: "VIDEO",
    skills: ["Video Editing", "Motion Graphics", "Storytelling", "Content Creation"]
  },
  {
    category: "AI",
    skills: [
      "AI Image Generation",
      "Prompt Engineering",
      "AI Visual Direction",
      "AI Creative Workflows",
      "AI-assisted Design",
      "AI Automation"
    ]
  },
  {
    category: "DEVELOPMENT",
    skills: [
      "HTML",
      "CSS",
      "JavaScript",
      "Responsive Web Design",
      "Basic Web Development"
    ]
  }
];

export const REAL_TOOLS = [
  { name: "Photoshop", category: "Design" },
  { name: "Canva", category: "Design" },
  { name: "Google AI Studio", category: "AI" },
  { name: "ChatGPT", category: "AI" },
  { name: "Figma", category: "UI/UX" },
  { name: "Adobe Tools", category: "Creative" }
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    step: "01",
    title: "DISCOVER",
    description: "Understand the idea, audience and objective.",
    details: "Deep dive into your brand's core mission, target demographics, and creative goals. We map out what makes your project unique and establish clear criteria for success."
  },
  {
    step: "02",
    title: "STRATEGIZE",
    description: "Define the visual direction and solution.",
    details: "Translate insights into moodboards, stylistic benchmarks, typography pairings, and structured creative roadmaps before producing initial drafts."
  },
  {
    step: "03",
    title: "CREATE",
    description: "Design, build and refine the concept.",
    details: "Hands-on execution across graphic layouts, brand symbols, video assemblies, or AI-generated visual pipelines. Bringing the core vision into high-definition reality."
  },
  {
    step: "04",
    title: "REFINE",
    description: "Review details and improve the experience.",
    details: "Scrutinizing kerning, contrast, frame pacing, responsiveness, and export fidelity. Polishing every detail until the deliverable feels seamless and authoritative."
  },
  {
    step: "05",
    title: "DELIVER",
    description: "Deliver the final polished result.",
    details: "Packaging production-ready deliverables, master assets, video exports, guidelines, and handoff documentation ready for immediate real-world deployment."
  }
];

export const WHY_WORK_WITH_ME = [
  {
    id: "human-ai",
    title: "HUMAN + AI",
    summary: "I combine creative thinking with modern AI tools.",
    description: "Leveraging state-of-the-art AI generation and automation without sacrificing human nuance, taste, or emotional resonance."
  },
  {
    id: "detail-focused",
    title: "DETAIL-FOCUSED",
    summary: "Small details matter in strong design.",
    description: "Obsessive care given to typographic scale, alignment rhythms, color contrast, and micro-interactions that elevate good into unforgettable."
  },
  {
    id: "multi-skilled",
    title: "MULTI-SKILLED",
    summary: "Branding, content, design and digital tools under one creative workflow.",
    description: "Eliminate the friction of juggling multiple contractors. Get unified brand identity, video edits, UI design, and AI visuals from a single creator."
  },
  {
    id: "always-learning",
    title: "ALWAYS LEARNING",
    summary: "Constantly exploring new tools, technologies and creative techniques.",
    description: "Staying at the cutting edge of AI models, generative workflows, and modern web standards so your brand stays ahead of the curve."
  }
];
