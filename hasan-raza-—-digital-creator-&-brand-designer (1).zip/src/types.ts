export interface Project {
  id: string;
  name: string;
  category: string;
  shortDescription: string;
  year: string;
  coverImage: string;
  overview: string;
  challenge: string;
  concept: string;
  designDirection: string;
  process: string[];
  finalResult: string;
  toolsUsed: string[];
  liveUrl?: string;
  gallery: {
    title: string;
    caption: string;
    image: string;
  }[];
}

export type AiCategory = 'ALL' | 'AI ART' | 'AI PORTRAITS' | 'AI PRODUCTS' | 'AI ADS' | 'AI CONCEPTS';

export interface AiVisualItem {
  id: string;
  title: string;
  category: 'AI ART' | 'AI PORTRAITS' | 'AI PRODUCTS' | 'AI ADS' | 'AI CONCEPTS';
  aspectRatio: 'tall' | 'wide' | 'square';
  image: string;
  instagramUrl: string;
  promptConcept: string;
}

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  description: string;
  items: string[];
  isAiSpecialty?: boolean;
}

export interface SkillCategory {
  category: string;
  skills: string[];
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  details: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  projectType: string;
  budgetRange: string;
  message: string;
}
